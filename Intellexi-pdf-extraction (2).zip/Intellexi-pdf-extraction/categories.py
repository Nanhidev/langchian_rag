from flask import Blueprint,render_template,request,jsonify,url_for,redirect
from conn import *
import json
import ast
from datetime import datetime


categories_bp=Blueprint("Categories",__name__,template_folder="./app/templates",static_folder="./app/static")


@categories_bp.get("/categories")
def all_categories():
    """
    Render Home Page
    """
    categories = get_all_categories()
    return render_template("documentCategories.html", categories=categories)


@categories_bp.get("/add-category")
def addCategory():
    """
    Render Home Page
    """
    return render_template("addCategory.html")


@categories_bp.get("/category/<id>/")
def viewCategory(id):
    """
    Render Home Page
    """

    print("===================================View category")
    category = get_cat_by_id(id)
    print(category)
    return render_template("viewCategory.html", category=category,id=id)


@categories_bp.get("/delete-category/<id>/")
def deleteCategory(id):
    """
    Render Home Page
    """
    if get_files_by_category(id):
        delete_category_by_id(id)
        return jsonify({"status": True})
    else:
        return jsonify({"status": False})


@categories_bp.route("/edit-category/<id>", methods=["GET", "POST"])
def editCategoryForm(id):
    """
    Render Home Page
    """
    print("===================================edit category")

    if request.method == 'GET':
        category = get_cat_by_id(id)
        file_type = category['file_type']
        category_name = category['doc_category_name']
        conversion_ontology = json.dumps(category.get('conversion_ontology'))
        extraction_ontology = json.dumps(category.get('extraction_ontology'))
        prompt = category.get('prompt_instructions')
        print(conversion_ontology)
        return render_template("editCategory.html", id=id, category_name=category_name,
                               extraction_ontology=extraction_ontology, conversion_ontology=conversion_ontology,
                               prompt=prompt, file_type=file_type)

    elif request.method == 'POST':
        print(request.form)
        print("-----post-data----",request.data)
        doc_category_name = request.form.get("documentCategory")
        if doc_category_name:
            pass
        else:
            doc_category_name=request.json.get("documentCategory")
        print(doc_category_name)
        extraction_ontology = request.form.get("extractionOntology")
        conversion_ontology = request.form.get("conversionOntology")
        prompt_instructions = request.form.get("promptInstructions")
        print(extraction_ontology)
        print(conversion_ontology)
        if conversion_ontology:       
            cleaned_conversion_string = conversion_ontology.strip().replace('\r\n', '').replace('\r', '').replace(
                '\n', '')
            cleaned_conversion_json_string = ast.literal_eval(cleaned_conversion_string)
        try:
            if prompt_instructions:
                cleaned_prompt_string = prompt_instructions.strip()
            if extraction_ontology:
                cleaned_extraction_string = extraction_ontology.strip().replace('\r\n', '').replace('\r', '').replace(
                    '\n', '')

                cleaned_extraction_json_string = ast.literal_eval(cleaned_extraction_string)
                data = {
                    "doc_category_name": doc_category_name,
                    "extraction_ontology": cleaned_extraction_json_string,
                    "conversion_ontology": cleaned_conversion_json_string,
                    "prompt_instructions": cleaned_prompt_string,
                    "Last_Updated": datetime.now(),
                }
            elif prompt_instructions :
                data = {
                    "doc_category_name": doc_category_name,
                    "prompt_instructions": cleaned_prompt_string,
                    "Uploaded_time": datetime.now(),
                "conversion_ontology": cleaned_conversion_json_string
                }
            else:
                print("-----------------in else---------------------")
                data = {
                    "doc_category_name": doc_category_name,
                    "Uploaded_time": datetime.now()
                }
            res = update_document(id, data)
            if res:
                return jsonify({"status": True})
            else:
                return jsonify(res)
        except SyntaxError:
            print("--------expecting------------")
            return jsonify({"status": False})
    else:
        return redirect(url_for("doc_category_management"))

@categories_bp.route("/create-doc-category/", methods=['GET', 'POST'])
def create_doc_category():
    """
    Get the data from doc_category_management form
    - Document Catgeory Name
    - Extraction Ontology
    - Conversion Ontology
    - Prompt Instructions
    store in Db and provide ack to user and return to upload page
    """
    if request.method == "POST":
        print("----------------inside post -----------")
        file_type = request.form.get('fileType')
        doc_category_name = request.form.get("documentCategory",None)
        extraction_ontology = request.form.get("extractionOntology",None)
        conversion_ontology = request.form.get("conversionOntology",None)
        prompt_instructions = request.form.get("promptInstructions",None)
        print("extraction_ontology",extraction_ontology)
       
        if extraction_ontology:
            cleaned_extraction_string = (
                    extraction_ontology.strip()
                    .replace("\r\n", "")
                    .replace("\r", "")
                    .replace("\n", "")
                )
            cleaned_extraction_json_string = ast.literal_eval(cleaned_extraction_string)
            
        else:
            cleaned_extraction_json_string=None
           
        if conversion_ontology:
            cleaned_conversion_string = (
                conversion_ontology.strip()
                .replace("\r\n", "")
                .replace("\r", "")
                .replace("\n", "")
            )
            cleaned_conversion_json_string = ast.literal_eval(cleaned_conversion_string)
        else:
            cleaned_conversion_json_string=None
        if prompt_instructions:
            cleaned_prompt_string=prompt_instructions.strip()
        print("*****************filetyep--------------",file_type)
        if file_type == 'pdf':
            try:
                data = {
                    "doc_category_name": doc_category_name,
                    "extraction_ontology": cleaned_extraction_json_string,
                    "conversion_ontology": cleaned_conversion_json_string,
                    "prompt_instructions": cleaned_prompt_string,
                    "Uploaded_time": datetime.now(),
                    "file_type": file_type
                }
                res = insert_document(data)
                if res['status']:
                    return jsonify({"status": True})
                else:
                    return jsonify(res)
            except (SyntaxError, ValueError):
                return jsonify({"status": False})
        elif file_type in [
            "xlsx",
            "kyc",
            "scanned",
            "medicalForm",
            "image",
            "azureVision",
            "azureOpenAI",
        ]:
            try:
                data = {
                    "file_type": file_type,
                    "doc_category_name": doc_category_name,
                    "conversion_ontology": cleaned_conversion_json_string,
                    "prompt_instructions": cleaned_prompt_string,
                    "Uploaded_time": datetime.now()
                }
                print("------------posting--------")
                res = insert_document(data)
                print(res)
                if res['status']:
                    return jsonify({"status": True})
                else:
                    return jsonify(res)
            except (SyntaxError, ValueError):
                return jsonify({"status": False})
        else :
            try:
                data = {
                    "file_type": file_type,
                    "doc_category_name": doc_category_name,
                    "Uploaded_time": datetime.now()
                }

                res = insert_document(data)
                if res['status']:
                    return jsonify({"status": True})
                else:
                    return jsonify(res)
            except (SyntaxError, ValueError):
                return jsonify({"status": False})
    else:
        return redirect(url_for("doc_category_management"))