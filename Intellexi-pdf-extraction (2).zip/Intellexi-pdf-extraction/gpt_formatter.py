import os
import requests
import base64
from langchain.chains import LLMChain
from langchain_community.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from paddleocr import PaddleOCR
import json
import logging
from dotenv import load_dotenv
load_dotenv()


logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)  # Set the logger level to DEBUG
# Set file mode to 'a' (append mode)
handler = logging.FileHandler("flask_app.log", mode="a")
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
handler.setFormatter(formatter)
logger.addHandler(handler)

BOL_OUTPUT = {
    "Fleet": "Group of vehicles for transportation.",
    "Date/Time": "Timestamp of the transaction.",
    "Item Code": "Unique identifier for items.",
    "Proppant": "Material for hydraulic fracturing.",
    "BOL#": " Unique identifier for Bill of Lading.",
    "PO#": "Unique identifier for Purchase Order.",
    "Weight (short ton)": "Weight in short tons.",
    "Truck#": "Vehicle identifier.",
    "Time Loadout": "Time of loading.",
    "Transferred": "Transfer status.",
    "To Job": "Destination job or project.",
    "Return to Vendor": "Return status to vendor.",
    "To Yard": "Destination yard or facility.",
    "Write Off": "Removal from inventory records.",
}


class VisionExtractor:
    def __init__(self, image_path,output_structure=None,prompt=None) -> None:
        self.image_path = image_path
        self.output_structure=output_structure
        self.prompt=prompt

        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {os.getenv('OPENAI_API_KEY')}",
        }
        logger.info("           Intialized the Vision Extarctor. ")
    def payload(self, base64_image):
        if self.prompt and  self.output_structure:
            return {
            "model": "gpt-4-vision-preview",
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": f"{self.prompt} The Final Output Format is {self.output_structure} Make sure to check the appropriate output structure that matches the table provided from the above expected formats and format it into the appropriate one, do not provide any additional details. The final json data is:",
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{base64_image}",
                                "detail": "high",
                            },
                        },
                    ],
                }
            ],
            "max_tokens": 1000,
        }
        else:
            return {
                "model": "gpt-4-vision-preview",
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": f"Understand the content of the bill of lading image, extract the content into the following json format {BOL_OUTPUT}, identify and fill the values each field with its appropriate value identified in the content, if no value is found just use None do not provide any additional details",
                            },
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{base64_image}",
                                    "detail": "high",
                                },
                            },
                        ],
                    }
                ],
                "max_tokens": 1000,
            }

    def encode_image(self):
        with open(self.image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8")

    def extract(self):
        base64_image = self.encode_image()
        payload = self.payload(base64_image=base64_image)
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers=self.headers,
            json=payload,
        )
        print(response.json())
        json_res=response.json()
        return json_res


class GPTFormatter:

    def __init__(
        self, uploaded_image_path
    ) -> None:
        self.image_path=uploaded_image_path
        self.ocr_text=self.ocr_extractor()
        self.vision_formatted_json = None

    def visionResponseSynthesizer(self,expected_format=BOL_OUTPUT):
        MODEL_NAME = "gpt-3.5-turbo-16k"
        llm = ChatOpenAI(model_name=MODEL_NAME, temperature=0)

        template = """{prompt}
        The Sample JSON format of the final expected output is :{format_string}
        
        \n\nThe input extracted content is : {input}
        \n\nThe formatted JSON result is :"""
        prompt = """
    You are an expert in understanding json responses of the Gpt4Vision Model, your objective is to format the given content into the required json format while adhering to the following instructions:
    - Thoroughly understand each entity present in the content.
    - Map each entity to its respective values in the content.
    - Restrict the inclusion of entities solely to those specified in the final expected format; avoid introducing additional entities.
    - Confirm that each entity is associated with its appropriate value.
    - Check for correctness of each value if any mis-spelled words are identified replace with the most possible correct form of that word and if You cannot find an appropriate value for any of the entity leave it empty"""
        format_string = expected_format
        input_text = self.ocr_text
        try:
            print("#" * 20, "in side try")
            prompt_template = PromptTemplate(
                input_variables=["prompt", "format_string", "input"], template=template
            )
            llm_chain = LLMChain(llm=llm, prompt=prompt_template, output_key="result")
            output = llm_chain.invoke(
                {"prompt": prompt, "format_string": format_string, "input": input_text}
            )
            print(output["result"])
            return output["result"]

        except Exception as e:
            print("error in formatting is-----------", {e})
            return None

    def vision_extractor(self):
        ve=VisionExtractor(image_path=self.image_path)
        vision_formatted_json=ve.extract()
        self.vision_formatted_json=vision_formatted_json
        logger.info(f"PADDLE-OCR Extarcted Text is :\n\n {vision_formatted_json}")
        return vision_formatted_json

    def ocr_extractor(self):
        ocr = PaddleOCR(use_angle_cls=True)
        img_path = self.image_path
        result = ocr.ocr(img_path, cls=True)
        extracted_text = ""
        for idx in range(len(result)):
            res = result[idx]
            print(type(res))
            for line in res:
                print(type(line), line[-1][0])
                extracted_text += "\n" + line[-1][0]
        self.ocr_text=extracted_text
        print("after extarction --------------------------")
        logger.info(f"PADDLE-OCR Extarcted Text is :\n\n {extracted_text}")
        return extracted_text

    def format(self,format_structure):
        if not self.vision_formatted_json:
            vision_extracted=self.vision_extractor()
            logger.info(f"Vision Extarcted Text is :\n\n {vision_extracted}")
        if not self.ocr_text:
            ocr_extracted=self.ocr_extractor()
            logger.info(f"OCR Extarcted Text is :\n\n {ocr_extracted}")

        if self.ocr_text and self.vision_formatted_json:
            logger.info(f"Starting validation")
            return self.synthesize(format_structure)

    def synthesize(self,format_structure):
        print("                                              SYNTHESIZING                  ")
        logger.info(f"Evaluating GPTVision response with paddle-ocr content")
        final_formatted = self.visionResponseSynthesizer(
            expected_format=format_structure
        )
        print("-------------------", type(final_formatted))
        print(json.loads(final_formatted))
        final_formatted_json=json.loads(final_formatted)
        with open("f.json","w")as f:
            json.dump(final_formatted_json,f,indent=4)
        logger.warning(f"Corrected response after evaluation is: \n\n{final_formatted_json}")
        return final_formatted_json 