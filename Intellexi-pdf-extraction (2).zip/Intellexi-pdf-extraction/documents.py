
from flask import Blueprint,render_template,send_file,jsonify,request
from conn import *
import json
from zipfile import ZipFile
import ast
from datetime import datetime
from conn import add_extracted_formatted_data
documents_bp=Blueprint("Documents",__name__,template_folder="./app/templates",static_folder="./app/static")


def remove_extra_quotes(dictionary):
    modified_dict = {}
    for key, value in dictionary.items():
        # Remove extra quotes from the key
        modified_key = key.replace('"', "").replace("'", "")

        # If the value is a nested dictionary, recursively process it
        if isinstance(value, dict):
            modified_value = remove_extra_quotes(value)
        elif isinstance(value, list):
            # If the value is a list, recursively process each element
            modified_value = [
                remove_extra_quotes(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            # Remove extra quotes from the value if it's a string
            modified_value = (
                value.replace('"', "").replace("'", "")
                if isinstance(value, str)
                else value
            )

        # Update the modified dictionary with the new key-value pair
        modified_dict[modified_key] = modified_value

    return modified_dict


@documents_bp.get("/uploaded_docs")
def all_uploaded_documents():
    """
    Tabular view for presenting with all uploaded docs
    """
    try:
        docs = get_all_files()
        return render_template("uploadedDocs.html", docs=docs)
    except:
        return render_template("uploadedDocs.html", docs=[])

def extract_values_from_fomatted_data(formatted_json):
    values = []
    for val in formatted_json.values():
        if isinstance(val, dict):
            values.extend(extract_values_from_fomatted_data(val))
        else:
            values.append(val)

    return values

def remove_empty_fields(data):
    
    if isinstance(data, dict):
        return {
            k: remove_empty_fields(v)
            for k, v in data.items()
            if v and remove_empty_fields(v)
        }
    elif isinstance(data, list):
        return [remove_empty_fields(v) for v in data if v and remove_empty_fields(v)]
    else:
        return data
@documents_bp.get("/document/<id>")
def viewDocument(id):
    document = get_file_by_id(id)
    formatted_data=document.get("formatted_data")
    cs= document.get("confidence_scores")
    fc=document.get("formatted_with_confidence")
    try:
        if formatted_data:
            formatted_data=remove_extra_quotes(formatted_data)
            formatted_data = remove_empty_fields(formatted_data)
        if cs:
            cs=remove_extra_quotes(cs)
        if fc:
            fc=remove_extra_quotes(fc)
        data = {
                    "formatted_data": formatted_data,
                    "confidence_scores":cs,
                    "formatted_with_confidence":fc
            }
        add_extracted_formatted_data(id,data)
    except Exception as e:
        print("Error is ",e)
        pass
    category = get_cat_by_id(document['category_id'])
    print("------------",category["file_type"])
    # if category["file_type"]=="medicalForm":
    # return render_template('viewDocEval.html', document=document, category=category)
    return render_template('viewDocument.html', document=document, category=category)

@documents_bp.get('/delete_file/<id>/')
def delete_document(id):
    delete_file_by_id(id)
    return jsonify({"status": True})

@documents_bp.route("/upload_document", methods=['GET', 'POST'])
def upload_document_form():
    """
    Form to upload document and show the user with extracted and formatted text
    """
    if request.method == 'GET':
        doc_categories = get_all_docs()
        return render_template("uploadDoc.html", categories=doc_categories)
    elif request.method == 'POST':
        print("in post of upload documets")
        print(request.files)        
        category_id = request.form['documentCategory']
        cat=get_cat_by_id(category_id)
       
        file = request.files['file']
        file.save(os.path.join("UploadedFiles", file.filename))
        file_path = os.path.join("UploadedFiles", file.filename)
        print("----------printing path------------")
        if cat["file_type"]=="rag":
            data = {
                "category_id": category_id,
                "file_path": file_path,
                "notExtractable":True,
                "Uploaded_time": datetime.now()
            }
            res = insert_file(data)
            return jsonify(res)
        else:
            data = {
                "category_id": category_id,
                "file_path": file_path,
                "notExtractable":False,
                "Uploaded_time": datetime.now()
            }
            res = insert_file(data)
            return jsonify(res)

# Download category
@documents_bp.get('/download_category/<id>/')
def download_category(id):
    '''
    download the category data 
    -> if file_type : PDF [ ontologies and prompts]
    -> if file_type : xlsx [prompt]

    => new method
            Write the whole data into the json irrespective of filetype
    '''
    temp_dir = 'temp_download'
    os.makedirs(temp_dir, exist_ok=True)

    file_paths = []
    data = get_cat_by_id(id)

    file_path = os.path.join(temp_dir, 'category.json')
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=2, default=str)
    file_paths.append(file_path)

    zip_file_path = 'downloaded_files.zip'
    with ZipFile(zip_file_path, 'w') as zip_file:
        for file_path in file_paths:
            zip_file.write(file_path, os.path.basename(file_path))

    for file_path in file_paths:
        os.remove(file_path)

    os.rmdir(temp_dir)
    return send_file(zip_file_path, as_attachment=True)

# sending multiple files
@documents_bp.get('/download_multiple_files/<id>/')
def download_multiple_files(id):
    temp_dir = 'temp_download'
    os.makedirs(temp_dir, exist_ok=True)

    file_paths = []
    data = get_file_by_id(id)

    file_path = os.path.join(temp_dir, 'extracted_data.json')
    with open(file_path, 'w') as file:
        json.dump(data.get('extracted_text'), file, indent=2, default=str)
    file_paths.append(file_path)

    file_path = os.path.join(temp_dir, 'formatted_data.json')
    try:
        with open(file_path, 'w') as file:
            if isinstance(data.get('formatted_data'), dict):
                json.dump(data.get('formatted_data'), file, indent=2, default=str)
            elif isinstance(data.get('formatted_data'), str):
                formatted_text = ast.literal_eval(data.get('formatted_data'))
                json.dump(formatted_text, file, indent=2)
    except:
        pass

    file_paths.append(file_path)

    zip_file_path = 'downloaded_files.zip'
    with ZipFile(zip_file_path, 'w') as zip_file:
        for file_path in file_paths:
            zip_file.write(file_path, os.path.basename(file_path))

    for file_path in file_paths:
        os.remove(file_path)

    os.rmdir(temp_dir)
    return send_file(zip_file_path, as_attachment=True)
