import base64
import anthropic
import base64
import cv2
from paddleocr import PaddleOCR
from dotenv import load_dotenv
import os
from conn.mongodb import add_extracted_formatted_data,get_file_by_id
from utils import replace_none_with_empty_string,replace_single_quotes
import json
from gpt_formatter import VisionExtractor
from langchain.output_parsers.json import SimpleJsonOutputParser

from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain.chat_models.openai import ChatOpenAI
load_dotenv()

load_dotenv()

print("API_-----------------", os.getenv("ANTHROPIC_API_KEY"))
client = anthropic.Anthropic(
    api_key=os.getenv("ANTHROPIC_API_KEY")
)

Table_prompt = """
Your proficiency in understanding handwritten content from tables and handwritten forms shines through, effortlessly decoding the nuances of any script. Your responsibility lies in converting the data captured in provided image of a table into the designated JSON format, meticulously following the given instructions:
The task is to idnetify tables in particular and process them.

1. Identify the table or tables in the image.
2. Identify the column names in the table paying close attention to the borders of the columns.
3. Identify the rows  in the table paying close attention to the border of each row starting from the header of the table.
4. Extract the handwritten content for each cell accurately paying close attention to each character of the handwritten text in the cell by understanding the expected value in the cell based on the column name and description.

5. Return the JSON response as the final output, adhering strictly to the specified format.
6. Include only the JSON response without additional descriptions or explanations.
"""

final_eval_prompt = """
Your proficiency in interpreting handwritten content across different styles and fonts guarantees precision. Your responsibility includes assessing handwritten data extracted from images alongside the provided extracted data over an iterative approach, ensuring accuracy through essential corrections while strictly following instructions.


1. Thoroughly examine the structure of the form in the image and identify the handwritten data and the labels it belongs to.
2. For each attribute identified in the json data, verify its presence in the image.
    - Check if the handwritten data in the image matches the corresponding values in the JSON, Pay attention to each character of the handwriten content and extract the correct value of the data.
    - Make sure that you identify the handwritten content correctly mainly in the case of numerical digits (i.e. account number, Date of birth, Age etc...) pay close attention in identifying them.
    - Do not move on to conclusion on the identified value, make sure that the value you identified is accurately correct as the handwritten content may differ from handwriting to handwriting,  
    - Strictly Identify the borders while extracting and segrate the data into the column that is filled into, and do not mismatch the data of one column or cell into other. 
3. If there are discrepancies between the handwritten content in the image and the JSON data, flag them for correction.
4. Identify tabular structures within the form. For each row of the table, verify the extracted data against the JSON data, ensuring accuracy in content and structure. also Make sure that each row data is extarcted accurately, also match the check whether the data in the column matches the expected value of the column based on the name or description of the column, and assign the correct value for the column.
5. Make necessary corrections to the JSON data to ensure it accurately reflects the handwritten content in the image. Correct any inaccuracies or mismatches between the image content and the JSON values.
6. While formatting the final json ensure that you understand the context of the each entity as per the description and the name of the key in the final json structure, adjust the structure of data from the tables accronding to the column it refers to i.e strictly identify address to be the name of a place, name is persons name make sure to segrate the data strictly based on the borders of the columns and rows, and be clear of any misleading handwriting and understand the content precicely and accurately. 
7. Assemble the corrected JSON data, maintaining the same structure as the provided JSON. Ensure that the final JSON output accurately represents all the content from the image, including tabular data.
8. Strictly return the corrected JSON response without additional descriptions or explanations. 


"""

def extract_text_using_ocr(image_path):
    ocr = PaddleOCR(use_angle_cls=True)
    ocr_response = ocr.ocr(image_path)
    extracted_text = ""
    print(ocr_response[0])
    if ocr_response[0]:
        for ele in ocr_response[0]:
            if ele:
                extracted_text += " " + ele[-1][0]
    return extracted_text


class MedicalFormFormatter:
    def __init__(self,image_url,prompt,conversion_ontology,doc_id,epochs=3) -> None:
        self.doc_id=doc_id
        self.image_url=image_url
        self.prompt=prompt
        self.conversion_ontology=conversion_ontology
        self.text=extract_text_using_ocr(image_path=self.image_url)
        self.epochs = epochs

    def encode_image(self):
        with open(self.image_url, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8")

    def detect_and_crop_tables(self):
        image = cv2.imread(self.image_url)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 150)
        contours, _ = cv2.findContours(
            edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        min_contour_area = 1000  # Adjust as needed
        min_table_width = 300  # Adjust as needed
        tables = []
        for contour in contours:
            area = cv2.contourArea(contour)
            x, y, w, h = cv2.boundingRect(contour)
            if (
                area > min_contour_area
                and w > min_table_width
                and (h > 300 and h < 700)
            ):
                table = image[y : y + h, x : x + w]
                tables.append(table)
        images = []
        # Save or display each cropped table
        for i, table in enumerate(tables):
            img_name = f"table_new_{i+1}.jpg"
            images.append(img_name)
            cv2.imwrite(f"table_new_{i+1}.jpg", table)
        return images

    def extract_using_claude(self,body):
        image_data = self.encode_image()
        image_type = self.image_url.split(".")[-1]
        if image_type == "jpg":
            image_type = "jpeg"
        image_media_type = f"image/{image_type}"
        message = client.messages.create(
            model="claude-3-opus-20240229",
            max_tokens=2024,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": image_media_type,
                                "data": image_data,
                            },
                        },
                        {
                            "type": "text",
                            "text": body
                        },
                    ],
                }
            ],
        )
        print(message.content[0].text)
        return message.content[0].text

    def output_processor(self, formatted_data,key):
        print("*" * 20, type(formatted_data))
        replace_none_with_empty_string(formatted_data)
        formatted_data = replace_single_quotes(formatted_data)
        print("\n\n")
        print(formatted_data)
        print("\n\n")
        try:
            if isinstance(formatted_data, dict):
                pass
            else:
                formatted = json.loads(formatted_data)
                print("formated is ----------", type(formatted))
        except json.JSONDecodeError as e:
            print("-----------     ERROR  -----", e)
            parser = SimpleJsonOutputParser()
            parsed_json = parser.parse(formatted_data)
            print("-------AFter Parsing -----------", type(parsed_json))
            if isinstance(parsed_json, (dict, list)):
                formatted = parsed_json
            else:
                formatted = None
        if formatted is not None:
            replace_none_with_empty_string(formatted)
            formatted = replace_single_quotes(formatted)
            data = {key: formatted}
        else:
            data = {key: "Error Processing"}
        add_extracted_formatted_data(self.doc_id, data)
        return formatted

    def extraction_1(self):
        body = f"{self.prompt}\n\n The final Required Json Format is {self.conversion_ontology}\nFor reference  Use the ocr extracted text from the same image in case if you do not understand any of the handwritten content.\nThe Paddle Ocr Extarcted Text is {self.text}\nStrictly return the Json response Only, no more descriptions or explanations. The Final Json is:"
        formatted_data=self.extract_using_claude(body=body)
        print("*" * 20, type(formatted_data))
        result=self.output_processor(formatted_data=formatted_data,key="formatted_data1")        
        self.formatted_data1 = result
        print("completed------------LEVEL 1------------------------------------------")

    def eval_using_claude(self, table_data=None):
        print("     --------------- image Url", self.image_url)
        if table_data:
            eval_prompt = f"You are an expert in understanding handwritten content accurately. Now, given the image of a handwritten data-filled form and the data identified from it, you are tasked with validating and making necessary corrections to the extracted data using the Claude-3-Opus model. The previously extracted content is {self.formatted_data1}.  The data from the tables is extarcted using GPT4-Vision. The main goal is to verify and make necessary corrections to ensure the utmost accuracy of the handwritten content in the provided image. The GPT4-Vision extracted tables data is {table_data}. Make sure the final response follows the JSON structure of the previous output. And Consolidate the final json with all accurate values detected on multiple steps. Strictly return only the JSON response, without providing any additional descriptions or explanations. The final corrected JSON is:"
        else:
            eval_prompt = f"You are an expert in understanding handwritten content accurately. Now, given the image of a handwritten data-filled form and the data identified from it, you are tasked with validating and making necessary corrections to the extracted data using the Claude-3-Opus model. The previously extracted content is {self.formatted_data1}.  The main goal is to verify and make necessary corrections to ensure the utmost accuracy of the handwritten content in the provided image. Make sure the final response follows the JSON structure of the previous output. Strictly return only the JSON response, without providing any additional descriptions or explanations. The final corrected JSON is:"
        image_data = self.encode_image()
        image_type = self.image_url.split(".")[-1]
        if image_type == "jpg":
            image_type = "jpeg"
        image_media_type = f"image/{image_type}"
        message = client.messages.create(
            model="claude-3-opus-20240229",
            max_tokens=2024,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": image_media_type,
                                "data": image_data,
                            },
                        },
                        {
                            "type": "text",
                            "text": eval_prompt,
                        },
                    ],
                }
            ],
        )
        print(message.content[0].text)
        return message.content[0].text

    def gpt_formatterr_on_tables(self):
        tables=self.detect_and_crop_tables()
        table_outputs=[]
        if tables:
            for table in tables:
                ve = VisionExtractor(
                    image_path=table,
                    output_structure=[self.prompt],
                    prompt=Table_prompt
                )
                text=ve.extract()
                table_outputs.append(text)
            use_tables=True
        else:
            use_tables=False

        if use_tables:
            final_eval_data=self.eval_using_claude(table_data=table_outputs)
        else:
            final_eval_data=self.eval_using_claude()

        return final_eval_data

    def extraction_2(self):
        formatted_data2=self.gpt_formatterr_on_tables()
        print("*" * 20, type(formatted_data2))
        result=self.output_processor(formatted_data=formatted_data2,key="formatted_data2")        
        self.formatted_data1 = result
        print("completed------------LEVEL 2------------------------------------------")

    def final_extracion(self):
        doc=get_file_by_id(self.doc_id)
        step1_formatted_data=doc.get("formatted_data1")
        step2_formatted_data = doc.get("formatted_data2")
        body = f"{final_eval_prompt}\n\n The final Required Json Format is {self.conversion_ontology}\n. The previously formatted data from the same image previously was through using the combination of GPT4-Vision, paddleocr extracted content and claude3-opus model as well.\nThe previously formatted data in step1 is \n{step1_formatted_data}\n The formatted data in step 2 is \n{step2_formatted_data}\nFor reference  Use the ocr extracted text from the same image in case if you do not understand any of the handwritten content.\nThe Paddle Ocr Extarcted Text is {self.text}\nStrictly use the context from previous formatted data and the image as well, and strictly return the Json response Only, no more descriptions or explanations. The Final Json is:"

        final_formatted_data=self.extract_using_claude(body=body)
        final_formatted_data=self.structure_organizer(data=final_formatted_data)
        print("*" * 20, type(final_formatted_data))
        result = self.output_processor(
            formatted_data=final_formatted_data, key="formatted_data"
        )
        self.formatted_data1 = result
        print("completed------------LEVEL 3------------------------------------------")

        print("-------------------------------------        Final Formatting        -----------------")
        return result

    def structure_organizer(self,data):
        llm = ChatOpenAI(model_name="gpt-3.5-turbo-16k", temperature=0)
        print("#" * 20, "in side try")
        template = """{prompt}
                
                \nThe Json content is : {input}
                \nThe Reorganized and validated JSON result is :"""
                
        prompt="""
        You are an expert in understanding json response, your objective is to understand the json content provided which is extracted from a form using gpt vision and claude 3 models and make necessary changes based on the following instructions:
        
        The Intent of this is to make sure that one column might be misinterpreted and assigned for value in someother column or also might be a chance where values from multiple columns might be interpreted into a single column.
            
            Now your task is to identify each object as a row and keys of it as the names of the column,
            
            for each key in the object:
                - check the value in the input data provided and verify if the value is corretly assigned to the column based on the context of both the key and value, if not find the appropriate column name and reorganize the object with in itself with the appropriate key 
                - Think clearly while identifying the entity value of each column and strictly organize the data as of was picked from a tabular structure.
            ***Example***:
            example 1: if the object has {{"Name of the Nominee": "MICHAEL INDORE",
            "Address": "FRIEND",
            "Nominee's Relationship with Member": "",
            "Date of Birth": "01/01/94",
            "Total Amount or Share of Provident Fund to Each Nominee": "51/-",
            "If Nominee is a Minor, Name and Address of Guardian": "KAMLESH"}}
            be smart enough to idetify that ROHIT is the name and PUNE is a place, and FRIEND is a relation and not an address, so the final reorganized object should be 
            {{"Name of the Nominee": "MICHAEL ",
            "Address": "INDORE",
            "Nominee's Relationship with Member": "FRIEND",
            "Date of Birth": "01/01/94",
            "Total Amount or Share of Provident Fund to Each Nominee": "51/-",
            "If Nominee is a Minor, Name and Address of Guardian": "KAMLESH"}}
            
            ***********************************
            Now repeat the same form of understanding on the input data and ake appropriate restructurings with in the object withthe values in it.
            
        Strictly, do not add any extra content, or miss any content, only reorganise the values understanding the context of the key and value within the structure
        """
                

        prompt_template = PromptTemplate(
            input_variables=["prompt", "input"], template=template
        )
        llm_chain = LLMChain(llm=llm, prompt=prompt_template, output_key="result")
        output = llm_chain.invoke(
            {"prompt": prompt, "input": data}
        )
        print("output is ----")
        print(output["result"])
        print(type(output["result"]))
        return output["result"]

            

    def start_eval(self):
        self.extraction_1()
        self.extraction_2()
        final_data=self.final_extracion()
        return final_data