def replace_none_with_empty_string(data):
    if isinstance(data, dict):
        for key, value in data.items():
            if value is None:
                data[key] = ""
            else:
                replace_none_with_empty_string(value)
    elif isinstance(data, list):
        for item in data:
            replace_none_with_empty_string(item)


def replace_single_quotes(obj):
    if isinstance(obj, dict):
        return {key: replace_single_quotes(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [replace_single_quotes(item) for item in obj]
    elif isinstance(obj, str):
        return obj.replace("'", "")
    else:
        return obj