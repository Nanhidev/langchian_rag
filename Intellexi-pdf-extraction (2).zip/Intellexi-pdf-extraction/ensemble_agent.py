from llama_index.core import SimpleDirectoryReader
from llama_index.llms.openai import OpenAI
from llama_index.core import Settings
from llama_index.core import StorageContext
import os
import openai
from llama_index.core import SimpleKeywordTableIndex, VectorStoreIndex
from llama_index.core import PromptTemplate
from llama_index.core.tools import QueryEngineTool
from llama_index.core.query_engine import RouterQueryEngine
from llama_index.core.selectors import LLMSingleSelector, LLMMultiSelector
from llama_index.core.selectors import (
    PydanticMultiSelector,
    PydanticSingleSelector,
)
from llama_index.core.response_synthesizers import TreeSummarize
import asyncio

OPENAI_API_KEY=os.environ["OPENAI_API_KEY"] 

openai.api_key = OPENAI_API_KEY


async def ensembleAgent(filepaths,query):
    file_names=[]
    for file_name in filepaths:
        file_names.append(os.path.basename(str(file_name)))
    # wiki_titles = filepaths
    print("file_names:",file_names)

    documents=[]
    for filename in file_names:
        loader = SimpleDirectoryReader(
            input_files=[f"./UploadedFiles/{filename}"]
        ).load_data()
        documents.extend(loader)
    print("documents:==",documents)

    Settings.llm = OpenAI(temperature=0, model="gpt-3.5-turbo")
    Settings.chunk_size = 512

    nodes = Settings.node_parser.get_nodes_from_documents(documents)
    # initialize storage context (by default it's in-memory)
    storage_context = StorageContext.from_defaults()
    storage_context.docstore.add_documents(nodes)

    keyword_index = SimpleKeywordTableIndex(
        nodes,
        storage_context=storage_context,
        show_progress=True,
    )
    vector_index = VectorStoreIndex(
        nodes,
        storage_context=storage_context,
        show_progress=True,
    )
    


    QA_PROMPT_TMPL = (
        "Context information is below.\n"
        "---------------------\n"
        "{context_str}\n"
        "---------------------\n"
        "Given the context information and not prior knowledge, "
        "answer the question. If the answer is not in the context, inform "
        "the user that you can't answer the question - DO NOT MAKE UP AN ANSWER.\n"
        "In addition to returning the answer, also return a relevance score as to "
        "how relevant the answer is to the question. "
        "Question: {query_str}\n"
        "Answer (including relevance score): "
    )

    QA_PROMPT = PromptTemplate(QA_PROMPT_TMPL)

    keyword_query_engine = keyword_index.as_query_engine(
        text_qa_template=QA_PROMPT
    )
    vector_query_engine = vector_index.as_query_engine(text_qa_template=QA_PROMPT)

    keyword_tool = QueryEngineTool.from_defaults(
        query_engine=keyword_query_engine,
        description="Useful for answering questions about inside content in the file",
    )

    vector_tool = QueryEngineTool.from_defaults(
        query_engine=vector_query_engine,
        description="Useful for questions related to all aspects in the file",
    )

    TREE_SUMMARIZE_PROMPT_TMPL = (
    "Context information from multiple sources is below. Each source may or"
    " may not have \na relevance score attached to"
    " it.\n---------------------\n{context_str}\n---------------------\nGiven"
    " the information from multiple sources and their associated relevance"
    " scores (if provided) and not prior knowledge, answer the question. If"
    " the answer is not in the context, inform the user that you can't answer"
    " the question.\nQuestion: {query_str}\nAnswer: "
    )

    tree_summarize = TreeSummarize(
        summary_template=PromptTemplate(TREE_SUMMARIZE_PROMPT_TMPL)
    )

    query_engine = RouterQueryEngine(
        selector=LLMMultiSelector.from_defaults(),
        query_engine_tools=[
            keyword_tool,
            vector_tool,
        ],
        summarizer=tree_summarize,
    )

    response =await query_engine.aquery(str(query))
    # print(response)
    return response

# # Example usage
# filepaths = ["/UploadedFiles/WorkingCaseStudies.pdf","/UploadedFiles/66085f3b7dba2-showcasing-innovative-greece.pdf"]
#              #"UploadedFiles/WorkingCaseStudies.pdf"]
# query = "What are the annexes in this"#"get the Table of contents"#"Can you find table of content "#"What are the point define under the key benefit of Retail | App Dev | Cloud"  # Corrected query string
# print(asyncio.run(ensembleAgent(filepaths, query)))