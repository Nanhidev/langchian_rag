import os
import re
from typing import List, Dict
from llama_index.core import (
    VectorStoreIndex,
    SimpleKeywordTableIndex,
    SimpleDirectoryReader,
    ComposableGraph,
)
from llama_index.core.schema import IndexNode
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.llms.openai import OpenAI
from llama_index.core.callbacks import CallbackManager
from pathlib import Path
import requests

from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import Settings
from llama_index.agent.openai import OpenAIAgent
from llama_index.core import load_index_from_storage, StorageContext
from llama_index.core.node_parser import SentenceSplitter

from dotenv import load_dotenv
load_dotenv()


from openai import OpenAI

# client = OpenAI()

import os

OPENAI_API_KEY=os.environ["OPENAI_API_KEY"] 
client = OpenAI(api_key=OPENAI_API_KEY)


delimiter = "####"
system_message = f"""
You are an experienced summary performer.It should cover all the information in the file.Returned summarized the text."""


def using_top_agent_with_llama(filepaths: List[str], query: str) -> str:
    wiki_titles = [str(i).split("\\")[-1] for i in filepaths]

    city_docs = {}
    wiki_title_summaries = {}
    agents = {}

    for wiki_title in wiki_titles:
        city_docs[wiki_title] = SimpleDirectoryReader(
            input_files=[f"UploadedFiles/{wiki_title}"]
        ).load_data()

        # print(city_docs[wiki_title])
        text = [doc.text for doc in city_docs[wiki_title]]

        print("Combined text:")

        formatted_text = "\n".join(text)

        # response = client.chat.completions.create(
        # model="gpt-3.5-turbo",
        # messages=[
        #     {"role": "system", "content": system_message},
        #     {"role": "user", "content": f"{delimiter}{formatted_text}{delimiter}"},#formatted_text},
        # ],
        # temperature=0.0

        # )
        # extracted_info=response.choices[0].message.content.strip()
        # print(extracted_info)
        # print("wiki_title_summary:", extracted_info)
        wiki_title_summaries[wiki_title] = formatted_text

    node_parser = SentenceSplitter()

    all_nodes = []
    indexes = []
    for idx, wiki_title in enumerate(wiki_titles):
        nodes = node_parser.get_nodes_from_documents(city_docs[wiki_title])
        all_nodes.extend(nodes)
        wiki_title = wiki_title.split(".")[0]
        index = VectorStoreIndex(nodes)
        indexes.append(index)
        print("nodes===", nodes)

    print(list(wiki_title_summaries.keys()))
    print("[index for index in indexes]=========", [index for index in indexes])

    graph = ComposableGraph.from_indices(
        SimpleKeywordTableIndex,
        [
            index for index in indexes
        ],  # Use list comprehension to extract VectorStoreIndex objects
        index_summaries=list(wiki_title_summaries.values()),
        max_keywords_per_chunk=50,
    )

    query_engine = graph.as_query_engine()

    response = query_engine.query(query)

    print(response)
    return response


# # Example usage
# filepaths = ["UploadedFiles/MOS-one-pager.pdf", "UploadedFiles/AXIS (1).pdf"]
# query = "Explain about small caps funnd?"
# print(using_top_agent_with_llama(filepaths, query))

