import anthropic
import base64
import httpx
import cv2
from gpt_formatter import VisionExtractor
from paddleocr import PaddleOCR
import os
from dotenv import load_dotenv

load_dotenv()

client = anthropic.Anthropic(
    api_key=os.getenv("ANTHROPIC_API_KEY")
)
final_1=[
        {
            "Name of the Nominee": "Person nominated to receive the Provident Fund.",
            "Address": "Nominee's address.",
            "Nominee's Relationship with Member": "Relation of the nominee to the user.",
            "Date of Birth": "Nominee's date of birth.",
            "Total Amount or Share of Provident Fund to Each Nominee": "Share of the Provident Fund allocated to the nominee.",
            "If Nominee is a Minor, Name and Address of Guardian": "Guardian's details if the nominee is a minor.",
            "Closing Description": "Conditions regarding nomination cancellation and dependency of parents.",
            "Strike Out Irrelevant Sentences": " To remove inapplicable statements.",
            "Signature/Thumb Impression of the Subscriber": "User's signature or thumb impression.",
        }
    ]
final_2=[
        {
            "Sr. No": "Sequence number.",
            "Name and Address of Family Member": "Full name and address of the family member.",
            "Age": "Age of the family member.",
            "Relationship with Member": "Relationship of the family member with the user.",
        }
    ]
Table_prompt = """
Your proficiency in understanding handwritten content shines through, effortlessly decoding the nuances of any script. Your responsibility lies in converting the data captured in provided image of a table into the designated JSON format, meticulously following the given instructions:

1. Identify the table in the image.
2. Identify the column names in the table paying close attention to the borders of the columns.
3. Identify the rows  in the table paying close attention to the border of each row starting from the header of the table.
4. Extract the handwritten content for each cell accurately paying close attention to each character of the handwritten text in the cell by understanding the expected value in the cell based on the column name and description.

5. Return the JSON response as the final output, adhering strictly to the specified format.
6. Include only the JSON response without additional descriptions or explanations.
"""

def extract_text_using_ocr(image_path):
    ocr = PaddleOCR(use_angle_cls=True)
    ocr_response = ocr.ocr(image_path)
    extracted_text = ""
    print(ocr_response[0])
    if ocr_response[0]:
        for ele in ocr_response[0]:
            print(ele)
            if ele:
                extracted_text += " " + ele[-1][0]

    return extracted_text
class ClaudeFormatter:
    def __init__(self, image_url, doc_id, prompt_instructions,conversion_ontology) -> None:
        self.image_url=image_url
        self.doc_id=doc_id
        self.prompt=prompt_instructions
        self.conversion_ontology = conversion_ontology
        self.text=extract_text_using_ocr(image_path=self.image_url)
        
    def encode_image(self):
        with open(self.image_url, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8")

    

    def extract_using_claude(self):
        print("     --------------- image Url", self.image_url)
        image_data = self.encode_image()
        image_type = self.image_url.split(".")[-1]
        if image_type == "jpg":
            image_type = "jpeg"
        image_media_type = f"image/{image_type}"
        message = client.messages.create(
            model="claude-3-opus-20240229",
            max_tokens=2024,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": image_media_type,
                                "data": image_data,
                            },
                        },
                        {
                            "type": "text",
                            "text": f"{self.prompt}\n\n The final Required Json Format is {self.conversion_ontology}\nFor reference  Use the ocr extracted text from the same image in case if you do not understand any of the handwritten content.\nThe Paddle Ocr Extarcted Text is {self.text}\nStrictly return the Json response Only, no more description. The Final Json is:"
                        },
                    ],
                }
            ],
        )
        print(message.content[0].text)
        return message.content[0].text


class ClaudeEvaluator:
    def __init__(
        self, image_url, doc_id, prompt_instructions, formatted_data
    ) -> None:
        self.image_url = image_url
        self.doc_id = doc_id
        self.prompt = prompt_instructions
        self.formatted_data = formatted_data

    def encode_image(self):
        with open(self.image_url, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8")

    def detect_and_crop_tables(self):
        image = cv2.imread(self.image_url)
        height, width, _ = image.shape
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 50, 150)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        min_contour_area = 1000  # Adjust as needed
        min_table_width = 300  # Adjust as needed
        tables = []
        for contour in contours:
            area = cv2.contourArea(contour)
            x, y, w, h = cv2.boundingRect(contour)
            if area > min_contour_area and w > min_table_width and (h > 300 and h < 700):
                table = image[y : y + h, x : x + w]
                tables.append(table)
        images=[]
        # Save or display each cropped table
        for i, table in enumerate(tables):
            print(i)
            img_name = f"table_new_{i+1}.jpg"
            images.append(img_name)
            cv2.imwrite(f"table_new_{i+1}.jpg", table)
        return images

    def eval_using_claude(self,table_data=None):
        print("     --------------- image Url", self.image_url)
        if table_data:
            eval_prompt = f"You are an expert in understanding handwritten content accurately. Now, given the image of a handwritten data-filled form and the data identified from it, you are tasked with validating and making necessary corrections to the extracted data using the Claude-3-Opus model. The previously extracted content is {self.formatted_data}.  The data from the tables is extarcted using GPT4-Vision. The main goal is to verify and make necessary corrections to ensure the utmost accuracy of the handwritten content in the provided image. The GPT4-Vision extracted tables data is {table_data}. Make sure the final response follows the JSON structure of the previous output. And Consolidate the final json with all accurate values detected on multiple steps. Strictly return only the JSON response, without providing any additional descriptions. The final corrected JSON is:"
        else:
            eval_prompt = f"You are an expert in understanding handwritten content accurately. Now, given the image of a handwritten data-filled form and the data identified from it, you are tasked with validating and making necessary corrections to the extracted data using the Claude-3-Opus model. The previously extracted content is {self.formatted_data}.  The main goal is to verify and make necessary corrections to ensure the utmost accuracy of the handwritten content in the provided image. Make sure the final response follows the JSON structure of the previous output. Strictly return only the JSON response, without providing any additional descriptions. The final corrected JSON is:"
        image_data = self.encode_image()
        image_type = self.image_url.split(".")[-1]
        if image_type == "jpg":
            image_type = "jpeg"
        image_media_type = f"image/{image_type}"
        message = client.messages.create(
                model="claude-3-opus-20240229",
                max_tokens=2024,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": image_media_type,
                                    "data": image_data,
                                },
                            },
                            {
                                "type": "text",
                                "text": eval_prompt,
                            },
                        ],
                    }
                ],
            )
        print(message.content[0].text)
        return message.content[0].text

    def start_eval(self):
        # if tables for each table extarct data using gpt and use the same output from 1st iter and tables output and image to cluade for consolidation and evalutions
        tables=self.detect_and_crop_tables()
        table_outputs=[]
        if tables:
            for table in tables:
                ve = VisionExtractor(
                    image_path=table,
                    output_structure=[final_1, final_2],
                    prompt=Table_prompt
                )
                text=ve.extract()
                table_outputs.append(text)
            use_tables=True
        else:
            use_tables=False

        if use_tables:
            final_eval_data=self.eval_using_claude(table_data=table_outputs)
        else:
            final_eval_data=self.eval_using_claude()
        
        return final_eval_data
    