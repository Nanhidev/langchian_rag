import os
from langchain.chains import LLMChain
from langchain_community.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate
from dotenv import load_dotenv

load_dotenv()

# MODEL_NAME = 'gpt-3.5-turbo'
MODEL_NAME='gpt-4o-mini'
def summary_fn(input_text:str,prompt:str, format_string=None):
    llm = ChatOpenAI(model_name=MODEL_NAME,temperature=0)
    '''
    Provided the Input Text(Raw extracted text), Conversion format (format_string) and the prompt 
    prompt the OpenAi model and return the response received 
    '''
    if format_string:
        template = """{prompt}
        The Sample JSON format of the final expected output is :{format_string}
        
        \n\nThe input extracted content is : {input}
        \n\nThe formatted JSON result is :"""
    else:
        template = """{prompt}
        
        \n\nThe input extracted content is : {input}
        \n\nThe formatted JSON result is :"""

    try:
        print('#'*20,"in side try")
        prompt_template = PromptTemplate(input_variables=["prompt", "format_string","input"], template=template)
        llm_chain = LLMChain(llm=llm, prompt=prompt_template, output_key="result")
        output = llm_chain.invoke({'prompt':prompt, 'format_string':format_string,'input': input_text })
        print(output["result"])
        return output["result"]
    
    except Exception as e:
        print("error in formatting is-----------",{e})
        return None
    