from datetime import datetime
import os
import json

def create_extraction_directory():

    TIMESTAMP_DIRECTORY=(datetime.now().strftime('%Y-%m-%d-%H-%M-%p'))
    if not os.path.exists(TIMESTAMP_DIRECTORY):
        os.makedirs(TIMESTAMP_DIRECTORY)

    # return os.path.join(os.getcwd(),TIMESTAMP_DIRECTORY)
    return TIMESTAMP_DIRECTORY
