"""
Methods for extracting data from pdf files
"""
import json
import fitz
import re
from app.GPT.gpt import summary_fn
from .pdf_extract_helper import get_best_hit, brute_force
from pdf2image import convert_from_path
from paddleocr import PaddleOCR
from pdf2image import convert_from_path


def extract_text_from_image(image_path):
    # ocr = PaddleOCR(use_angle_cls=True)
    # img_path = image_path
    # result = ocr.ocr(img_path, cls=True)
    # extracted_text = ""
    # for idx in range(len(result)):
    #     res = result[idx]
    #     print(type(res))
    #     for line in res:
    #         print(type(line), line[-1][0])
    #         extracted_text += "\n" + line[-1][0]
    # print("---------extrated image---------------")
    # input("---------extrated image---------------")
    # return extracted_text
    #print("------1--imagepath",image_path)
    # ocr = PaddleOCR(use_angle_cls=True)
    # result = ocr.ocr(image_path, cls=True)
    # extracted_text = ""
    # print("------2--imagepath",image_path)
    # # Extracting text from OCR result
    # for idx in range(len(result)):
    #     res = result[idx]
    #     for line in res:
    #         extracted_text += "\n" + line[-1][0]
    # print("---------extrated image---------------")
    # print("----------------input-----------")
    # return extracted_text
    ocr = PaddleOCR(lang='ar', use_angle_cls=True)
    extracted_text = ""
    results = ocr.ocr(image_path)
    
    for line in results[0]:
        extracted_text += "\n" + line[1][0]  # Append recognized text to the result
  
    cleaned_text = " ".join(extracted_text.split()) 
    return cleaned_text


def extract_text_from_scanned_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    text=''
    print("pages------------",doc.page_count)
    if doc.page_count==1:
        print("-------------             block 1")
        images = convert_from_path(pdf_path, dpi=200, first_page=1, last_page=1)
        images[0].save(f"image_1.png")
        page_text = extract_text_from_image(f"image_1.png")
        print(page_text)
        print("finally1")

        return page_text
    else:
        for page in range(doc.page_count):
            images = convert_from_path(pdf_path, dpi=300, first_page=page, last_page=page)
            try:
                images[0].save(f"image_{page}.png")
                print(f"-----------image{page}.png")
                page_text = extract_text_from_image(f"image_{page}.png")
                print(page_text)
                text += page_text
            except:
                pass
            
            print("finally2")
        return text



def extract_text(pdf_path: str) -> str:
    """
    pdf_path - file url
    returns the pdf data as a string
    """
    doc = fitz.open(pdf_path)
    pdf_data = ""
    for page in range(doc.page_count):
        pdf_data += doc[page].get_text()
    print("inside exarct_text-----------------------------")
    if len(pdf_data)>20:
        print("returning here")
        return pdf_data
    else:
        print("xtarcting as image")
        text = extract_text_from_scanned_pdf(pdf_path)
        return text


def brute_force_end_keyword(pdf_data, start_index, record):
    pdf_data = pdf_data[start_index:]
    text = record["StopKeyword"]
    hits = []
    word = ""
    text_list = text.strip().split(" ")
    for each in text_list:
        word += each.strip()
        found = re.search(word, pdf_data)
        word += " "
        if found is not None:
            hits.append((found.start(), found.end()))

    starting_index = get_best_hit(hits)
    trimmed_data = pdf_data[starting_index:]
    text_end = trimmed_data.find(text_list[-1])
    return start_index + starting_index + len(record["StopKeyword"])


def extract(pdf_file: str, extraction: dict):
    """
    pdf_file - file path
    extraction - the extration ontology
    """
    #pdf_data = extract_text(pdf_file)
    # data in string
    #extracted_output = {}
    # empty dic
    # if extraction:
    #     for doc in extraction:
    #         extracted = []
    #         for record in extraction[doc]:
    #             text = {}
    #             start_index = pdf_data.find(record["StartKeyword"])
    #             if start_index != -1:
    #                 of_interest = pdf_data[start_index + len(record["StartKeyword"]) :]
    #                 end_index = of_interest.find(record["StopKeyword"])
    #                 if end_index != -1:
    #                     end_index = (
    #                         start_index
    #                         + len(record["StartKeyword"])
    #                         + end_index
    #                         + len(record["StopKeyword"])
    #                     )
    #                     text[record["Section"]] = pdf_data[start_index:end_index]
    #                 else:
    #                     text[record["Section"]] = brute_force_end_keyword(
    #                         pdf_data, start_index, record
    #                     )
    #             else:
    #                 start_index, start_end = brute_force(
    #                     pdf_data, record["StartKeyword"]
    #                 )
    #                 if start_index == -1 or start_end == -1:
    #                     text[record["Section"]] = (
    #                         "Sorry Could not Find the Keywords provided"
    #                     )
    #                     continue
    #                 end_index = pdf_data[start_index + start_end :].find(
    #                     record["StopKeyword"]
    #                 )
    #                 if end_index != -1:
    #                     text[record["Section"]] = pdf_data[start_index:end_index]
    #                 else:
    #                     end_index = brute_force_end_keyword(pdf_data, start_end, record)
    #                     text[record["Section"]] = pdf_data[start_index:end_index]
    #             extracted.append(text)
    #         extracted_output[doc] = extracted
    #     return extracted_output
    # else:
    #     return pdf_data
    pdf_data = extract_text(pdf_file)
    extracted_output = {}
    pdf_data=re.sub(r'\s+', ' ', pdf_data).strip()
    if not extraction:
        return pdf_data,False

    for record in extraction:
        section_name = record["Section"]
        start_keyword = record["StartKeyword"]
        start_keyword=re.sub(r'\s+', ' ', start_keyword).strip()
        stop_keyword = record["StopKeyword"]
        stop_keyword=re.sub(r'\s+', ' ', stop_keyword).strip()
        section_text = ""

        

        x = re.search(start_keyword, pdf_data)
        y = re.search(stop_keyword, pdf_data)


        if x==None:            
            extracted_output[section_name] = "starting Word not matched in pdf"            
            return extracted_output, True
        if y==None:     
            extracted_output[section_name] = "ending Word not matched in pdf"
            return extracted_output, True
            
        if start_keyword==stop_keyword:
            extracted_output[section_name] = "both the starting word and Ending words are same",True

        if len(start_keyword)==0 and len(stop_keyword)==0:
            extracted_output[section_name] = pdf_data
            return extracted_output,False
        else:
            if len(stop_keyword)==0:
                section_text = pdf_data[x.start():].strip()
            else:
                section_text=pdf_data[:y.end()].strip()

        # if x != None :
            
        #     if y != None:
                
        #         section_text=pdf_data[x.start():y.end()].strip()
        #         print("-------------in section_text-------------",section_text)
        #     else:
                
        #         section_text = pdf_data[x.start():].strip()
        # elif x==None and y!=None:
        #     section_text=pdf_data[:y.end()].strip()
            
        # else:   
        #     section_text =pdf_data

        extracted_output[section_name] = section_text
        print("===========finish Here=================",extracted_output)

    return extracted_output, False


def format_to_conversionOntology(raw_text, convertion_ontology, prompt,use_format=None):
    if use_format=="yes":
        print("&" * 100)
        conversion_string = str(convertion_ontology).replace("{", "{{").replace("}", "}}")
        print("#" * 100)
    else:
        conversion_string=None
        
    output = summary_fn(
        input_text=raw_text, format_string=conversion_string, prompt=prompt
    )
    print("#" * 100)
    if output is None:
        return None
    else:
        formatted_string = output
        formatted_string = formatted_string.replace("json", "").strip(" `")
        #valid_json = formatted_string.replace("'", '"')
        print(type(formatted_string))
        print(formatted_string)
        # Step 3: Parse the JSON data
        #valid_json=json.dump(formatted_string)
        data = json.loads(formatted_string)

        
        
        return data
