import re

def brute_force(pdf_data,text):
    '''
    checks for each word in the keywords provided in the text and returns starting and ending position of the text keyword 
    '''
    hits=[]
    word=''
    text_list=text.strip().split(' ')
    for each in text_list:
        
        if each!='':
            word+=each
            found=(re.search(word,pdf_data))
            word+=' '
            if found is not None:
                hits.append((found.start(),found.end()))

    start_index=get_best_hit(hits)
    if start_index==-1:
        return -1,-1
    else:
        trimmed_data=pdf_data[start_index:]
        # text_end=trimmed_data.find(text_list[-1])

        # wrt pdf_data passd to the function
        return start_index ,start_index+len(text)
    

def get_best_hit(hits):
    start_index={}
    for each in hits:
        if each[0] in start_index:
            start_index[each[0]]+=1
        else:
            start_index[each[0]]=1
    try:
        max_value = max(start_index.values())
        max_keys = [key for key, value in start_index.items() if value == max_value]
        return max_keys[0]

    except  ValueError:
        return -1 

