import xlrd
import openpyxl
import os

def get_sheets(file_path:os.path)->list:
    '''
    Loads an Excel File at location(filepath) for assesing the sheets present in the file
    
    Args:
        param file_path(path): The filepath for excel file to be opened
        returns sheets(list): The list of sheet names present in the file 
    Raises:
        File not Found: when teh filepath provided is not found.
    
    '''
    if os.path.exists(file_path):
        if file_path.endswith('.xls'):
            excel=xlrd.open_workbook(file_path)
            sheets=excel.sheet_names()
        else:
            excel=openpyxl.load_workbook(file_path)
            sheets=excel.sheetnames
        return sheets
    else:
        raise FileNotFoundError(f'File not Found at {file_path}')
    

    