import math
from extract_write_data import extract_data
from datetime import datetime


def convert_datetime_to_str(value):
    """ Converts datetime to string  """
    if isinstance(value, datetime):
        return value.strftime('%Y-%m-%d %H:%M:%S')
    elif isinstance(value, list):
        return [convert_datetime_to_str(item) for item in value]
    elif isinstance(value, dict):
        return {convert_datetime_to_str(key): convert_datetime_to_str(val) for key, val in value.items()}
    else:
        return value


def get_header_section(df, to_index, i_name):
    """ fetches the first header row of headers """
    header_section = []
    dicts = {}
    key = None
    for index in range(0, to_index):
        inds = df.iloc[index][df.iloc[index].notna()].index.to_list()
        if len(inds) == 1:
            if key is None:
                key = df.iloc[index][inds[0]]
            else:
                if len(dicts) > 0:
                    header_section.append({key: dicts})
                    dicts = {}
                else:
                    header_section.append({key: ''})
                key = df.iloc[index][inds[0]]
        elif len(inds) == 2:
            dicts[df.iloc[index][inds[0]]] = df.iloc[index][inds[1]]
        else:
            dicts[df.iloc[index][inds[0]]] = [df.iloc[index][inds[index]] for index in range(len(inds))]
    if key is not None and len(dicts) != 0:
        header_section.append({key: dicts})
        key = None
    else:
        header_section.append(dicts)
    header_data = convert_datetime_to_str(header_section)
    return header_data, key


def complete_header(df, header_row, vc):
    head = df.iloc[header_row]

    if header_row == 0:
        return head, header_row
    for index in range(header_row + 1, df.shape[0]):
        new_headers = []
        if df.iloc[index].notna().sum() in vc[:2]:
            return head, index
        else:
            tail = df.iloc[index]
            for h, t in zip(head, tail):
                if isinstance(t, float) and math.isnan(t):
                    new_headers.append(str(h).strip())
                else:
                    new_headers.append(str(str(h) + ' ' + str(t)).strip())
            head = new_headers
    return None, None


def find_header_row(df, sheet_name):
    """ checks if shape of file is not (0,0) and segregate the headers """
    if df.shape != (0, 0):
        main_header = -1
        df.notna().sum(axis=1).value_counts()
        vc = list(df.notna().sum(axis=1).value_counts().keys())
        for index in range(df.shape[0]):
            if ((len(vc) > 5 and df.iloc[index].notnull().sum() in vc[:2] and 1 not in vc[:2]) or
                    df.iloc[index].notnull().sum() == max(vc)):
                main_header = index
                break
        if any(x in vc[:2] for x in (1, 2)):
            vc.sort(reverse=True)
        if df.iloc[main_header + 1].notna().sum() in vc[:2]:
            header = df.iloc[main_header]
            header_section, head_key = get_header_section(df, main_header, sheet_name)
            extract_data(df=df, header=header, data_index=main_header + 1, sheet_name=sheet_name,
                         header_data=header_section, head_key=head_key)
        else:
            header, data_index = complete_header(df, main_header, vc)
            header_section, head_key = get_header_section(df, main_header, sheet_name)
            extract_data(df=df, header=header, data_index=data_index, sheet_name=sheet_name, header_data=header_section,
                         head_key=head_key)
