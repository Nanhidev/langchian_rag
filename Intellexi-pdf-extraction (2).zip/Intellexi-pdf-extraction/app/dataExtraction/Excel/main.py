from column_plan import colplan
from row_plans import get_inpatients_outpatients
from sheets_data import get_sheets
from headers import find_header_row
import os
import pandas as pd


def main(file_path):
    """
    The function starts here. The main funtion will check if the sheet contains ('Inpatient', 'Outpatient') sheets
    if present then main will invoke get_inpatients_outpatients else it will check first row header
    """
    if not os.path.exists('extractions/'):
        os.makedirs('extractions')
    sheets = get_sheets(file_path)
    if all(sheet in sheets for sheet in ['Inpatient', 'Outpatient']):
        """ checks if sheet is inpatient or outpatient """
        get_inpatients_outpatients(file_path)
        return
    for sheet in sheets:
        df = pd.read_excel(file_path, sheet_name=sheet, header=None, index_col=None)
        df.dropna(how='all', inplace=True, axis=0)
        try:
            find_header_row(df, sheet)
        except Exception as e:
            if str(e) == "Col Plan":
                colplan(file_path, sheet)
            else:
                raise Exception(e)


if __name__ == '__main__':
    main('/home/walkingtree/Downloads/NYP Empire BCBS.xlsm')
    main('./files/WMC UHC.xlsx')
    main('./files/WMC UHC.xlsx')
