import json
from app.GPT.utils import create_extraction_directory

def extract_data(df, header, data_index, sheet_name, header_data, head_key):
    """ Combining the data and storing into json file """
    print("============Extracting Data")
    data_dict = [{"header": header_data}]
    data_section = []
    df_e = df.fillna('')
    for index in range(data_index, df.shape[0]):
        record = {}
        for head, data in zip(header, df_e.iloc[index]):
            if isinstance(head, str):
                if len(head) > 50:
                    raise Exception("Col Plan")
                else:
                    record[head] = data
            else:
                record[head] = data

        data_section.append(record)
    if head_key:
        data_dict.append({head_key: data_section})
    else:
        data_dict.append(data_section)
    dir_path=create_extraction_directory()
    with open(f'{dir_path}/{sheet_name}.json', 'w') as de:
        json.dump(data_dict, de, indent=2, default=str)
        print("============DONE============")
