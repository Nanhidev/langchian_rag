import pandas as pd
import json,os
from app.GPT.utils import create_extraction_directory

"""
when the plan details are in excel with each plan in each column and the service categories as row level headers, if you have any better approach in dealing with it feel free to update your logic

"""

def create_plan(header:list,plan:list)->dict:
    """
    Given the header of the file returns a dict with {col_name:val} for each row in the sheet

    Args:
        header (list): A list of Header Names of the sheet
        plan (list): A list of single row values of the sheet

    Returns:
        plan_obj (dict):A dictionary with column name as key and it's corresponding value of the key.

    Raises:
        Exceptions to be found and handled
    """
    plan_header=zip(header,plan)
    plan_obj={}
    for each in plan_header:
        plan_obj[each[0]]=each[1]
    return plan_obj


def get_notes(plans_df:pd.DataFrame)->dict:
    '''
    Given a dataframe with its lastcolumn as Notes regarding the row level header values
    concatenates or appends the dict as {"Notes":notes} for each corresponding key

    Args:
        plans_df (Pandas DataFrame): the dataframe object that row level header on first column and last column consists of notes

    Returns:
        notes_dict (dict): Dictionary of notes with header name as key and a nested dictionary with
        {
            "header_name":
            {
                "notes":notes
            }
        }
    '''


    header=plans_df.iloc[:,0]
    notes=plans_df.iloc[:,-1]
    notes_dict={}
    for x in zip(header,notes):
        notes_dict[x[0]]=x[1]
    return notes_dict


def create_notes_plans(plans:dict,notes:dict,plan_name:str)->dict:
    """
    Given a dictionary of notes and plans which are basedon same header values,
    destructures them into a single structure based on the key value of each dictionary (plans,notes)

    Args:
        plans (dict): Dictionary of plans with key -> "header name", value -> "value of the plan"
        notes (dict): Dictionary of notes with key -> "header name", value -> "value of the note"
        plan_name (str) : Name of the plan the data is related to. [In the General sense Its the header value if considered in terms of columns]
    """
    plan_dict={}
    for key in plans.keys():
        plan_dict[key]={}
        plan_dict[key]["Value"]=plans[key]
        plan_dict[key]["notes"]=notes[key]
    return plan_dict

def create_section(plan_dict:dict)->dict:
    '''
    Based on the Dictionary Values of a single Plan. Here, we refine the structure into 3 sections namely
    Header, Inpatient, Outpatient and create a nested dictionary ased on there coreesponding values.

    Args:
        plan_dict (dict): Dictionary containing the label and value for a plan which is along the column.

    Return:
        plan_section (dict): Dictionary that is formatted into sections namely(Header, Inpatient,Outpatient)

    Raises:
        Find and Handle exceptions-------
    '''
    plan_section={"Header":{},"Inpatient":{},"Outpatient":{}}
    section='Header'
    for each in plan_dict.keys():
        if each in ['Inpatient','Outpatient']:
            if each=='Inpatient':
                section='Inpatient'
            else:
                section='Outpatient'

        plan_section[section][each]=plan_dict[each]
    return plan_section

def colplan(file_path:os.path,sheet:(str,int)=0)->None:
    """
    Given a file_path to an excel that contains data with Row level headers,
    extracts the data and maps each plan in each column with corresponding header value.
    Args:
        file_path (path): The filepath to find the
        sheet (str,int): Either the name of the sheet, or the index of the sheet to extract data from.

    Returns:
        None : Writes the data of each plan into a seperate json file.
    """
    df=pd.read_excel(file_path,sheet_name=sheet)
    df2=df.iloc[list(df.iloc[:,0]).index('Plan'):,:]
    df2.columns=df2.iloc[2,:]
    plans_col=df2.columns
    plans=plans_col.dropna()
    df2=df2.iloc[0:]
    df2[plans].to_excel('plan.xlsx',index=None)
    plans_df=pd.read_excel('./plan.xlsx')
    plans_df.fillna('',inplace=True)
    header=plans_df.iloc[1:,0]
    notes=get_notes(plans_df)

    plans_df=plans_df.iloc[:,1:]
    consider=plans_df.columns[:-1]
    for i,col in enumerate(consider):
        plan_code=col
        plan_df=plans_df[col][:]
        plan_obj=create_plan(header,plan_df)
        plan_dict=create_notes_plans(plan_obj,notes,plan_code)
        final_obj=create_section(plan_dict)
        dir_path=create_extraction_directory()
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)
        with open(f'{dir_path}/plan{i}.json','w')as f:
            json.dump(final_obj,f,indent=4,default=str)
    print("Extraction Completed")
    return None


# the incomplete code logic implementation
# based on row header

# from openpyxl import workbook,load_workbook
# import pandas as pd
# def find_rows_header(sheet):
#     coordinates=[]
#     for i,row in enumerate(sheet.iter_cols(max_col=1)):
#         for j,cell in enumerate(row):
#             if cell.font and not cell.font.color and cell.font.bold:
#                 coordinates.append((j,i))

#     return coordinates

# workbook=load_workbook('./WMC UHC - Copy.xlsx')
# sheet=workbook.active
# sheet
# coords=find_rows_header(sheet=sheet)


# import math
# df=pd.read_excel('./WMC UHC - Copy.xlsx',header=None,index_col=None)
# plans=[]
# print(df.shape)
# for index in range(2,df.shape[1]):
#     df2=df.iloc[:,[1,0,index]]
#     plan=[]
#     records=[]
#     key=None
#     head_id=None
#     header=None
#     for i in range(df2.shape[0]):
#         if any(coord[0] == i for coord in coords):
#             print("yes a header",i)
#             header=df2.iloc[i]
#             head_id=i
#             plan.append(records)
#             records=[]
#             continue
#         if header is not None:
#             print("header is===,",header)
#             if key is not None:
#                 record[key]=[]

#                 for head, val in zip(header,df2.iloc[i].tolist()):
#                     record[key].append(val)
#             elif len(header.tolist())==1: 
#                 plan.append(record)
#                 if df2.iloc[head_id].notna().sum()==1:
#                     key=df2.iloc[head_id].dropna()[0]
#                     record[key]=[]
#                 continue
#             else:
#                 record={} 
#                 for head, val in zip(header,df2.iloc[i].tolist()):
#                         if isinstance(head,float):
#                             if math.isnan(head):
#                                 pass
#                             else:
#                                 record[head]=val
#                         else:
#                             record[head]=val
#             plan.append(record)
#         else:
#             records.extend(df2.iloc[i].dropna().to_list())
#     plans.append(plan)


#     for i,data in enumerate(plans):
#         with open(f'data{i}.json','w') as f:
#             import json
#             json.dump(data,f,indent=4,default=str)