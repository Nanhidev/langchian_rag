'''
methods for extracting data from excel sheets
'''

from langchain_community.document_loaders import UnstructuredExcelLoader
import json
from bs4 import BeautifulSoup
from app.GPT.gpt import summary_fn
'''

excel  prompt:

Given JSON contract data with various rate categories, create a structured output under the key "Rate-Categories." Each entry should include:

Service Category
Rate
Rate Calculation Type
Notes
Codes
Example: For input 'CPT: 90791': '378.099575', 'CPT: 90791 Notes': 'Per Unit', the output should be:
{
  "Rate-Categories": [
    {
      "Service Category": "CPT",
      "Rate": "378.099575",
      "Rate Calculation Type": "Per Unit",
      "Notes": "Per Unit",
      "Codes": ["CPT-90791"]
    },
    ["other categories",]
  ]
}
Format all rate categories similarly, replacing code ranges with complete lists.
'''
# Reading Excel Document from file path
def extract_data_from_excel(file_path):
    print("==================extracting data================")
    doc=UnstructuredExcelLoader(file_path,mode='elements')
    sheets=doc.load()
    inpatients=sheets[0].metadata['text_as_html']
    outpatients=sheets[1].metadata['text_as_html']
    inpatients_records=extract_inpatients_records(inpatients)
    outpatients_records=extract_outpatients_records(outpatients)
    merged_records=merge_records(inpatients_records,outpatients_records)
    return merged_records


def format_row(prompt,row,format_string):
    output=summary_fn(input_text=row,prompt=prompt,format_string=format_string)
    return output


# inpatients
def extract_inpatients_records(inpatients):
    print("=================extrating inpatients data==========")
    soup=BeautifulSoup(inpatients,'html.parser')
    table_data=soup.find('table')
    rows=table_data.findAll('tr')
    inheader=rows[1]
    inheaders=[each.get_text() for each in inheader.findAll('td')]
    row_data=[]
    inheaders.__len__()
    for each in rows[2:]:
        row=[each.get_text() for each in each.findAll('td')]
        row_data.append(row)
    inpatients_records=[{key:value for key,value in zip(inheaders,row) if value!=''} for row in row_data]
    with open('inpatients.json','w') as inf:
        inf.write(json.dumps(inpatients_records))

    return inpatients_records

# outpatients
def extract_outpatients_records(outpatients):
    print("=================extrating outpatients data==========")
    outsoup=BeautifulSoup(outpatients,'html.parser')
    table_data=outsoup.find('table')
    rows=table_data.findAll('tr')
    outheader=rows[1]
    outheaders=[each.get_text() for each in outheader.findAll('td')]
    row_data2=[]
    outheaders.__len__()
    for each in rows[2:]:
        row=[each.get_text() for each in each.findAll('td')]
        row_data2.append(row)
        print(outheaders)


    outpatients_records=[{key:value for key,value in zip(outheaders,row) if value!=''} for row in row_data2]

    with open('outpatiendts.json','w') as inf:
        inf.write(json.dumps(outpatients_records))
    print(type(outpatients_records))
    return outpatients_records



# merging inpatient and outpatients sheets data
def merge_records(inpatients_records,outpatients_records):
    print("================= merging data==========")
    print(type(inpatients_records),type(outpatients_records))
    merged=[]
    for s1,s2 in zip(inpatients_records,outpatients_records):
        print(s1.keys(),s2.keys())
        if s1['ID']==s2['ID']:
            record={**s1,**s2}
            merged.append(record)
    with open('merged.json','w') as m:
        m.write(json.dumps(merged))

    return merged
