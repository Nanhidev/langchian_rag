import pandas as pd
import json
from app.GPT.utils import create_extraction_directory

def get_inpatients_outpatients(file_path):
    """ combines inpatient and outpatient sheet and dumps into json file (stored in extractions folder)"""
    inpatients = pd.read_excel(file_path, sheet_name='Inpatient')
    outpatients = pd.read_excel(file_path, sheet_name='Outpatient')

    df = pd.concat([inpatients, outpatients], axis=1)
    data_dict = []
    df.fillna('', inplace=True)
    headers = df.iloc[0, :]
    for index in range(1, df.shape[0]):
        record = {}
        for col, data in zip(headers, df.iloc[index]):
            if data != '':
                record[col] = data
        data_dict.append(record)
    dir_path=create_extraction_directory()
    with open(f'{dir_path}/Inpatinet_outpatients.json', 'w') as f:
        json.dump(data_dict, f, indent=4, default=str)
    
    return data_dict
