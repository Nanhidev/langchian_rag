from llama_index import VectorStoreIndex,ServiceContext,StorageContext,load_index_from_storage
from llama_index.tools import ToolMetadata,QueryEngineTool
from llama_index.query_engine import SubQuestionQueryEngine
# doc_1_data=""
# doc_2_data=""


# query_engine_tools = [
#     QueryEngineTool(
#         query_engine=doc_1_engine,
#         metadata=ToolMetadata(name="doc_1_engine", description="data about doc1"),
#     ),
#     QueryEngineTool(
#         query_engine=doc_2_engine,
#         metadata=ToolMetadata(name="doc_2_engine", description="data about doc2"),
#     ),
# ]

# s_engine=SubQuestionQueryEngine.from_defaults(query_engine_tools=query_engine_tools)

# res=s_engine.query("Compare and contrast the segements that grew the fastest?")


def build_simple_engine(documents,document_descriptions,persist_path):
    indexes=[]
    indexes.append(load_index_from_storage(persist_path))

    queryengines=[]
    for index in indexes:
        queryengines.append(index.as_query_engine(similarity_top_k=3))

    query_engine_tools=[]
    for i,engine,description in zip(documents,queryengines,document_descriptions):
        query_engine_tools.append(QueryEngineTool(
            query_engine=engine,
            metadata=ToolMetadata(name=f"doc_{i.id_}_engine",description=description)
        ))
        
    s_engine=SubQuestionQueryEngine.from_defaults(query_engine_tools=query_engine_tools)
    return s_engine