import * as popups from './popups.js';
const FileType = document.getElementById('FileType')
const category_id=document.getElementById('category_id').value
document.getElementById('docForm').addEventListener('keydown', function (e) {
  // Check if the pressed key is Enter
  console.log("yes")
  if (e.key === 'Enter') {
    if (!e.target.tagName === 'INPUT' || !e.target.tagName === 'TEXTAREA') {
      if (!confirm('Do you want to submit the form?')) {
        e.preventDefault();
      }
    }
  }
});
const doc_form = document.getElementById("docForm");
doc_form.addEventListener("submit", (e) => {
  e.preventDefault();
  const fileType = FileType.value;
  const conversionOntology = document.getElementById("conversionOntology");
  alert("error hereee")
  
  if (conversionOntology){
  var conversion_string  = conversionOntology.value;
  
  conversion_string = conversion_string.trim();
  conversion_string = conversion_string.replace(/\s+/g, " ");
  conversion_string = conversion_string.replace(/[\n\r]+/g, "");
  conversion_string = conversion_string
      .replace(/,\s*}/g, "}")
      .replace(/,\s*]/g, "]");
  }
  alert(conversion_string)
    if (fileType == "pdf") {
    
    const extractionOntology = document.getElementById("extractionOntology");
    let extraction_string = extractionOntology.value;
    extraction_string = extraction_string.trim();
    extraction_string = extraction_string.replace(/\s+/g, " ");
    extraction_string = extraction_string.replace(/[\n\r]+/g, "");
    extraction_string = extraction_string
      .replace(/,\s*}/g, "}")
      .replace(/,\s*]/g, "]");
   
    if (doc_form.checkValidity()) {
      alert(extraction_string)
      if (checkJsontype(extraction_string, conversion_string)) {
        alert("coming here")
        const docFormData = new FormData(doc_form);
        fetch(`/edit-category/${category_id}`, {
          method: "POST",
          body: docFormData,
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.status) {
              popups.showSuccessPopup();

              setTimeout(() => {
                popups.closeSuccessPopup();
                window.location.href = "/upload_document";
              }, 2000);
            } else {
              document.getElementById("documentCategoryError").textContent =
                data.message;

              setTimeout(() => {
                document.getElementById("documentCategoryError").textContent =
                  "";
              }, 2000);
              document.getElementById("documentCategory").scrollIntoView();
            }
          })
          .catch((error) => {
            console.error("Error:", error);
          });
      }
      
    }
    
  }  
  else if (fileType=="rag"){
    console.log("vision update")
      if (doc_form.checkValidity()) {
      console.log(`posting the data else ${fileType}`);
      const cat_name=document.getElementById("documentCategory").value
      const formData = new FormData();

// Add form data to the FormData object
formData.append("documentCategory", cat_name);

// Create a JSON payload
const payload = {
    "documentCategory": cat_name
};

// Stringify the JSON payload
const payloadString = JSON.stringify(payload);
      fetch(`/edit-category/${category_id}`, {
        method: "POST",
         headers: {
        'Content-Type': 'application/json', // Set the content type to multipart/form-data
        // If you need to send JSON data alongside form data, you can include it as a separate field
    },
        body: payloadString,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.status) {
            popups.showSuccessPopup();

            setTimeout(() => {
              popups.closeSuccessPopup();
              window.location.href = "/upload_document";
            }, 2000);
          } else {
            document.getElementById("documentCategoryError").textContent =
              data.message;
            setTimeout(() => {
              document.getElementById("documentCategoryError").textContent = "";
            }, 2000);
            document.getElementById("documentCategory").scrollIntoView();
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    }
  }
  else{
    if (doc_form.checkValidity()) {
      const docFormData = new FormData(doc_form);
      console.log(`posting the data else ${fileType}`);
      fetch(`/edit-category/${category_id}`, {
        method: "POST",
        body: docFormData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.status) {
            popups.showSuccessPopup();

            setTimeout(() => {
              popups.closeSuccessPopup();
              window.location.href = "/upload_document";
            }, 2000);
          } else {
            document.getElementById("documentCategoryError").textContent =
              data.message;
            setTimeout(() => {
              document.getElementById("documentCategoryError").textContent = "";
            }, 2000);
            document.getElementById("documentCategory").scrollIntoView();
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    }
  } 
  })


function checkJsontype(extraction_string, conversion_string = null) {
  alert("coming here1")
  if (extraction_string != null) {
    try {
      JSON.parse(extraction_string);
      alert("coming here2")
    } catch (error) {
      console.log("error while parsing extraction string", error);
      extractionOntology.classList.add("is-invalid");
      extractionOntology.classList.remove("is-valid");
      alert("coming here3")
      return false;
    }
    alert("coming here4")
    extractionOntology.classList.add("is-valid");
    extractionOntology.classList.remove("is-invalid");
  }
  try {
    JSON.parse(conversion_string);
  } catch (error) {
    console.log("error while parsing conversion string", error);
    conversionOntology.classList.add("is-invalid");
    conversionOntology.classList.remove("is-valid");
    return false;
  }
  conversionOntology.classList.remove("is-invalid");
  conversionOntology.classList.add("is-valid");
  return true;
}

