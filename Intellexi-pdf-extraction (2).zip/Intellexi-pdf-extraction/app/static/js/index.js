import * as popups from './popups.js';
const FileType = document.getElementById('FileType')

document.getElementById('docForm').addEventListener('keydown', function (e) {
  if (e.key === 'Enter') {
    if (!e.target.tagName === 'INPUT' || !e.target.tagName === 'TEXTAREA') {
      if (!confirm('Do you want to submit the form?')) {
        e.preventDefault();
      }
    }
  }
});
const doc_form = document.getElementById("docForm");
doc_form.addEventListener("submit", (e) => {
  e.preventDefault();
  
  const fileType = document.getElementById('fileType').value;
  var conversionOntology = document.getElementById("conversionOntology");
  if (conversionOntology) {
    var conversion_string = conversionOntology.value;
    conversion_string = conversion_string.trim();
    conversion_string = conversion_string.replace(/\s+/g, " ");
    conversion_string = conversion_string.replace(/[\n\r]+/g, "");
    conversion_string = conversion_string
      .replace(/,\s*}/g, "}")
      .replace(/,\s*]/g, "]");
  }

  let extraction_string = 'none';
  if (fileType == 'pdf') {
    const extractionOntology = document.getElementById('extractionOntology',null);
    
    if (extractionOntology == null || extractionOntology.value.trim() === '') {
      extraction_string = `[
    {
        "Section": "Section 1",
        "StartKeyword": "",
        "StopKeyword": ""
    }
]` ;  // Empty extraction string or default empty JSON
      document.getElementById('extractionOntology').value = `[
    {
        "Section": "Section 1",
        "StartKeyword": "",
        "StopKeyword": ""
    }
]`;
    } else {
      extraction_string = extractionOntology.value.trim();
      extraction_string = extraction_string.replace(/\s+/g, " ");
      extraction_string = extraction_string.replace(/[\n\r]+/g, "");
      extraction_string = extraction_string
        .replace(/,\s*}/g, "}")
        .replace(/,\s*]/g, "]");
    }

    // If the form is valid, proceed with the API call
    if (doc_form.checkValidity()) {
      if (checkJsontype(extraction_string, conversion_string)) {
        const docFormData = new FormData(doc_form);
        fetch("/create-doc-category/", {
          method: "POST",
          body: docFormData,
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.status) {
              popups.showSuccessPopup();
              setTimeout(() => {
                popups.closeSuccessPopup();
                window.location.href = "/upload_document";
              }, 2000);
            } else {
              document.getElementById("documentCategoryError").textContent = data.message;
              setTimeout(() => {
                document.getElementById("documentCategoryError").textContent = "";
              }, 2000);
              document.getElementById("documentCategory").scrollIntoView();
            }
          })
          .catch((error) => {
            console.error("Error:", error);
          });
      }
    }
  } else if (fileType == 'rag') {
    if (doc_form.checkValidity()) {
      const docFormData = new FormData(doc_form);
      fetch("/create-doc-category/", {
        method: "POST",
        body: docFormData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.status) {
            popups.showSuccessPopup();
            setTimeout(() => {
              popups.closeSuccessPopup();
              window.location.href = "/upload_document";
            }, 2000);
          } else {
            document.getElementById("documentCategoryError").textContent = data.message;
            setTimeout(() => {
              document.getElementById("documentCategoryError").textContent = "";
            }, 2000);
            document.getElementById("documentCategory").scrollIntoView();
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    }
  } else {
    if (doc_form.checkValidity()) {
      const docFormData = new FormData(doc_form);
      fetch("/create-doc-category/", {
        method: "POST",
        body: docFormData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.status) {
            popups.showSuccessPopup();
            setTimeout(() => {
              popups.closeSuccessPopup();
              window.location.href = '/upload_document';
            }, 2000);
          } else {
            document.getElementById('documentCategoryError').textContent = data.message;
            setTimeout(() => {
              document.getElementById('documentCategoryError').textContent = '';
            }, 2000);
            document.getElementById('documentCategory').scrollIntoView();
          }
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    }
  }
});

function checkJsontype(extraction_string, conversion_string = null) {
  if (extraction_string != null) {
    if (extraction_string === '{}' || extraction_string === 'none') {
      // If extraction string is empty or default, consider it as valid JSON
      return true;
    }
    try {
      JSON.parse(extraction_string);
    } catch (error) {
      console.log("error while parsing extraction string", error);
      extractionOntology.classList.add("is-invalid");
      extractionOntology.classList.remove("is-valid");
      return false;
    }
    extractionOntology.classList.add("is-valid");
    extractionOntology.classList.remove("is-invalid");
  }

  if (conversion_string != null) {
    try {
      JSON.parse(conversion_string);
    } catch (error) {
      console.log("error while parsing conversion string", error);
      conversionOntology.classList.add("is-invalid");
      conversionOntology.classList.remove("is-valid");
      return false;
    }
    conversionOntology.classList.remove("is-invalid");
    conversionOntology.classList.add("is-valid");
  }

  return true;
}

