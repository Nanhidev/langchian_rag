from llama_index.core import (
    VectorStoreIndex,
    SimpleKeywordTableIndex,
    SimpleDirectoryReader,
)
from llama_index.core import SummaryIndex
from llama_index.core.schema import IndexNode
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.llms.openai import OpenAI
from llama_index.core.callbacks import CallbackManager
import PyPDF2
import time
from pathlib import Path
import requests
from paddleocr import PaddleOCR
from pdf2image import convert_from_path

from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core import Settings

from llama_index.agent.openai import OpenAIAgent
from llama_index.core import load_index_from_storage, StorageContext
from llama_index.core.node_parser import SentenceSplitter
import os
import re
# import fitz
from llama_index.core import VectorStoreIndex
from llama_index.core.objects import ObjectIndex

from llama_index.agent.openai import OpenAIAgent
from flask import jsonify
from llama_index.core.schema import IndexNode, TextNode, NodeRelationship, RelatedNodeInfo, ObjectType
from config import OPENAI_API_KEY
from dotenv import load_dotenv
load_dotenv()
models = os.environ["model_name"]

def sanitize_file_name(file_name):
    base_file_name = str(file_name).split(".")[0]
    base_file_name = re.sub(r'[^\w\s-]', '_', base_file_name)  # Remove invalid characters
    base_file_name = re.sub(r'\s+', '_', base_file_name)       # Replace spaces with underscores
    match = re.search(r'\((\d+)\)', base_file_name)
    if match:
        number = match.group(1)
        base_file_name = re.sub(r'\s*\(\d+\)', f'_{number}', base_file_name)
    return base_file_name

def extract_text_from_image(image_path):
    ocr = PaddleOCR(use_angle_cls=True, lang='en')
    result = ocr.ocr(image_path, cls=True)
    text = ""
    for line in result:
        text += " ".join([word_info[1][0] for word_info in line]) + "\n"
    return text.strip()

def extract_text_from_pdf(pdf_path):
    try:
        images = convert_from_path(pdf_path)
        text = ""
        for idx, image in enumerate(images):
            image_path = f"/tmp/page_{idx}.png"
            image.save(image_path, 'PNG')
            image_text = extract_text_from_image(image_path)
            text += image_text + "\n"
            os.remove(image_path)  # Cleanup the temporary image file
        return text.strip()
    except Exception as e:
        print(f"Error extracting text from PDF {pdf_path}: {e}")
        return ""

def create_text_node(id_, text, metadata):
    relationships = {NodeRelationship.SOURCE: RelatedNodeInfo(
        node_id=id_,
        node_type=ObjectType.DOCUMENT,
        metadata=metadata,
        hash='e1d16a99db9b15188980ba2da82f67f91fb6212c7f664b63948e3a6fec141900'
    )}
    
    return TextNode(
        id_=id_,
        text=text,
        metadata=metadata,
        relationships=relationships
    )

def extract_text_from_PyPDF2(pdf_path):
    try:
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ""
            for page_num in range(len(reader.pages)):
                page = reader.pages[page_num]
                text += page.extract_text() + "\n"
            if text.strip():
                return text.strip()
            else:
                raise ValueError("Empty text detected in PDF, treating as image")
    except Exception as e:
        print(f"Error extracting text from PDF: {e}")
        images = convert_from_path(pdf_path)
        text = ""
        for idx, image in enumerate(images):
            image_path = f"/tmp/page_{idx}.png"
            image.save(image_path, 'PNG')
            image_text = extract_text_from_image(image_path)
            text += image_text + "\n"
            os.remove(image_path)  # Cleanup the temporary image file
        return text.strip()

def get_extracted_text(file_names):
    files = {}
    for file_name in file_names:
        print("file_name====",file_name)
        if file_name.lower().endswith('.pdf'):
            try:
                try:
                    files[file_name] = SimpleDirectoryReader(input_files=[os.path.join("UploadedFiles",f"{file_name}")]).load_data()
                    if not files[file_name][0].text.strip():
                        raise ValueError("Empty text detected in PDF, treating as image")
                except ValueError:
                    try:
                        print("====entered into exception=====")
                        text = extract_text_from_PyPDF2(os.path.join("UploadedFiles",f"{file_name}"))
                        metadata = {
                            'file_name': file_name,
                            'file_path': os.path.join("UploadedFiles",f"{file_name}"),
                            'file_type': 'application/pdf'
                        }
                        files[file_name] = [create_text_node(file_name, text, metadata)]
                       
                    except:
                        # Handle the case where the PDF content is actually images
                        image_text = extract_text_from_pdf(os.path.join("UploadedFiles",f"{file_name}"))
                        metadata = {
                            'file_name': file_name,
                            'file_path': os.path.join("UploadedFiles",f"{file_name}"),
                            'file_type': 'application/pdf'
                        }
                        files[file_name] = [create_text_node(file_name, image_text, metadata)]

                      
            except:
                print("====entered into exception2=====")
                image_text = extract_text_from_pdf(os.path.join("UploadedFiles",f"{file_name}"))
                metadata = {
                    'file_name': file_name,
                    'file_path': os.path.join("UploadedFiles",f"{file_name}"),
                    'file_type': 'application/pdf'
                }
                files[file_name] = [create_text_node(file_name, image_text, metadata)]
        else:
            print("====entered into else=====")
            image_text = extract_text_from_image(os.path.join("UploadedFiles",f"{file_name}"))
            metadata = {
                'file_name': file_name,
                'file_path': os.path.join("UploadedFiles",f"{file_name}"),
                'file_type': 'image'
            }
            files[file_name] = [create_text_node(file_name, image_text, metadata)]
    return files

def combine_vector_indices_and_summary_indices(*indices):
    combined_vectors = []
    combined_summaries = []

    for index in indices:
        print("Processing index:", index)

        vector_store_index = index.get("vector_index")
        if vector_store_index:
            vectors = vector_store_index  # Assuming vector_store_index contains vectors
            combined_vectors.append(vectors)
        else:
            print("Vector store or its method not found.")

        summary_index = index.get("summary_index")
        if summary_index:
            summaries = summary_index  # Assuming summary_index contains summaries
            combined_summaries.append(summaries)
        else:
            print("Summary index or its method not found.")

    print("Combined vectors:", combined_vectors)
    print("Combined summaries:", combined_summaries)

    return combined_vectors, combined_summaries



def vector_index_and_summary_index(file_names):
    file_names = [os.path.basename(str(file_name)) for file_name in file_names]
    start=time.time()
    node_parser = SentenceSplitter()
    # This is for the baseline
    all_nodes = []
    vector_indices_and_summary_indices = []

    for idx, file_name in enumerate(file_names):
        
        
        base_file_name = sanitize_file_name(file_name)
        persist_path=os.path.join(".","UploadedFiles_indexes",f"{base_file_name}")
        
        if not os.path.exists(persist_path):
            files=get_extracted_text(file_names)
            documents = files[file_name]
            nodes = node_parser.get_nodes_from_documents(documents)
            print("nodes:", nodes)
            all_nodes.extend(nodes)
            # Build vector index
            # vector_index = VectorStoreIndex(nodes)
            # vector_index.storage_context.persist(persist_dir=f"./UploadedFiles/{base_file_name}")
            vector_index = VectorStoreIndex(nodes)
            vector_index.storage_context.persist(persist_dir=persist_path)
            summary_index = SummaryIndex(nodes)
            summary_index.storage_context.persist(persist_dir=f"{persist_path}_summary")
        else:
            storage_context = StorageContext.from_defaults(persist_dir=persist_path)
            summary_storage_context = StorageContext.from_defaults(persist_dir=f"{persist_path}_summary")

            try:
                vector_index = load_index_from_storage(storage_context=storage_context)
                summary_index = load_index_from_storage(storage_context=summary_storage_context)
            except ValueError as e:
                print(f"Failed to load index: {e}")
                files=get_extracted_text(file_names)
                documents = files[file_name]
                nodes = node_parser.get_nodes_from_documents(documents)
                print("nodes:", nodes)
                all_nodes.extend(nodes)
                vector_index = VectorStoreIndex(nodes)
                vector_index.storage_context.persist(persist_dir=persist_path)
                summary_index = SummaryIndex(nodes)
                summary_index.storage_context.persist(persist_dir=f"{persist_path}_summary")

        vector_indices_and_summary_indices.append({"vector_index": vector_index, "summary_index": summary_index})
    end=time.time()
    vector_index,summary_index=combine_vector_indices_and_summary_indices(*vector_indices_and_summary_indices)
    print(f"Time taken to use index {end-start}")
    return vector_index,summary_index

def using_top_agent(filepaths, query):
    file_names = [os.path.basename(str(file_name)) for file_name in filepaths]
    print("file_names:", file_names)

    Settings.llm = OpenAI(temperature=0, model=models)
    Settings.embed_model = OpenAIEmbedding(model="text-embedding-ada-002")

    # Build agents dictionary
    agents = {}
    query_engines = {}
    all_tools = []

    vector_index_summary_index = vector_index_and_summary_index(file_names)
    print("vector_index, summary_index=====", vector_index_summary_index)

    for file_name, index_tuple in zip(file_names, zip(*vector_index_summary_index)):
        base_file_name = sanitize_file_name(file_name)
        print("index_tuple====>",index_tuple)
        vector_index, summary_index = index_tuple

        # Define query engines
        vector_query_engine = vector_index.as_query_engine(llm=Settings.llm)
        summary_query_engine = summary_index.as_query_engine(llm=Settings.llm)

        # Define tools
        query_engine_tools = [
            QueryEngineTool(
                query_engine=vector_query_engine,
                metadata=ToolMetadata(
                    name=f"vector_tool_{base_file_name}",
                    description=(
                        "Useful for questions related to all aspects of"
                        f" {base_file_name}."
                    ),
                ),
            ),
            QueryEngineTool(
                query_engine=summary_query_engine,
                metadata=ToolMetadata(
                    name=f"summary_tool_{base_file_name}",
                    description=(
                        "Useful for any requests that require a holistic summary"
                        f" of EVERYTHING about {base_file_name}. For questions about"
                        " more specific sections, please use the vector_tool."
                    ),
                ),
            ),
        ]

        # Build agent
        function_llm = OpenAI(model=models)
        agent = OpenAIAgent.from_tools(
            query_engine_tools,
            llm=function_llm,
            verbose=True,
            system_prompt=f"""\
            You are a specialized agent designed to answer queries about {base_file_name}.
            You must ALWAYS use at least one of the tools provided when answering a question; do NOT rely on prior knowledge.\
            """,
        )

        agents[base_file_name] = agent
        query_engines[base_file_name] = vector_index.as_query_engine(similarity_top_k=2)

        file_summary = (
            f"This content contains information about {base_file_name}. Use"
            f" this tool if you want to answer any questions about {base_file_name}.\n"
        )

        doc_tool = QueryEngineTool(
            query_engine=agent,
            metadata=ToolMetadata(
                name=f"tool_{base_file_name}",
                description=file_summary,
            ),
        )
        all_tools.append(doc_tool)

    obj_index = ObjectIndex.from_objects(
        all_tools,
        index_cls=VectorStoreIndex,
    )

    top_agent = OpenAIAgent.from_tools(
        tool_retriever=obj_index.as_retriever(vector_store_query_mode="mmr",
                                              similarity_top_k=3,
                                              vector_store_kwargs={"mmr_threshold": 0.5}),
        system_prompt="""\
    You are an agent designed to answer queries about a set of given files.
    Please always use the tools provided to answer a question. Do not rely on prior knowledge.\
    """,
        verbose=True,
    )

    response = top_agent.query(str(query))
    print(response)
    return response

