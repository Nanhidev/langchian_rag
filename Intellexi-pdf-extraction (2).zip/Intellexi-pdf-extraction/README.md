# Document Reader


- **Required Tools and Softwares**
  1. _MongoDB_ on _Local Machine_
  2. _Python_
  
  
  **STEPS**:
  1. create virtul env and activate venv 
  2. Run pip install -r requirements.txt
  3. Run _python app.py_ in the terminal directory of app.py 
  4. Open the endpoint http://localhost:5000/