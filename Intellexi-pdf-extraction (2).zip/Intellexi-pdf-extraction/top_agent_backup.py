import os
import re
from multiprocessing import Pool, cpu_count
from llama_index.core import (
    SimpleDirectoryReader,
    SummaryIndex,
    Settings,
    load_index_from_storage,
    StorageContext,
    VectorStoreIndex,
)
from llama_index.core.callbacks import CallbackManager
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.schema import IndexNode
from llama_index.core.tools import QueryEngineTool, ToolMetadata
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.llms.openai import OpenAI
from llama_index.agent.openai import OpenAIAgent
from llama_index.core.objects import ObjectIndex
from dotenv import load_dotenv
from flask import jsonify

load_dotenv()
print(os.getenv('OPENAI_API_KEY'))

def initialize_query_engines(file_names, files):
    node_parser = SentenceSplitter()
    agents = {}
    query_engines = {}

    for file_name in file_names:
        nodes = node_parser.get_nodes_from_documents(files[file_name])
        vector_index = VectorStoreIndex(nodes)
        vector_index.storage_context.persist(persist_dir=f"./UploadedFiles/{file_name}_index")
        summary_index = SummaryIndex(nodes)
        vector_query_engine = vector_index.as_query_engine(llm=Settings.llm)
        summary_query_engine = summary_index.as_query_engine(llm=Settings.llm)

        query_engine_tools = [
            QueryEngineTool(
                query_engine=vector_query_engine,
                metadata=ToolMetadata(
                    name="vector_tool",
                    description=(
                        f"Useful for questions related to all aspects of {file_name}."
                    ),
                ),
            ),
            QueryEngineTool(
                query_engine=summary_query_engine,
                metadata=ToolMetadata(
                    name="summary_tool",
                    description=(
                        f"Useful for any requests that require a holistic summary of EVERYTHING about {file_name}."
                    ),
                ),
            ),
        ]

        function_llm = OpenAI(model="gpt-3.5-turbo")
        agent = OpenAIAgent.from_tools(
            query_engine_tools,
            llm=function_llm,
            verbose=True,
            system_prompt=f"""\
    You are a specialized agent designed to answer queries about {file_name}.
    You must ALWAYS use at least one of the tools provided when answering a question; do NOT rely on prior knowledge.\
    """,
        )

        agents[file_name] = agent
        query_engines[file_name] = vector_index.as_query_engine(similarity_top_k=2)

    return agents, query_engines

def initialize_top_agent(agents):
    all_tools = []

    for file_name, agent in agents.items():
        file_summary = (
            f"This content contains information about {file_name}. Use "
            f"this tool if you want to answer any questions about {file_name}.\n"
        )
        
        doc_tool = QueryEngineTool(
                query_engine=agent,
                metadata=ToolMetadata(
                    name=re.sub(r'\W+', '_', file_name),
                    description=file_summary,
                ),
            )
        all_tools.append(doc_tool)

    obj_index = ObjectIndex.from_objects(
        all_tools,
        index_cls=VectorStoreIndex,
    )

    top_agent = OpenAIAgent.from_tools(
        tool_retriever=obj_index.as_retriever(
            vector_store_query_mode="mmr",
            similarity_top_k=3,
            vector_store_kwargs={"mmr_threshold": 0.5}
        ),
        system_prompt="""\
    You are an agent designed to answer queries about a set of given files.
    Please always use the tools provided to answer a question. Do not rely on prior knowledge.
    """,
        verbose=True,
    )

    return top_agent

def process_file(file_name):
    file_path = f"UploadedFiles/{file_name}"
    reader = SimpleDirectoryReader(input_files=[file_path])
    files = reader.load_data()
    return file_name, files

def using_top_agent(filepaths, query):
    file_names = [os.path.basename(filepath) for filepath in filepaths]

    with Pool(processes=cpu_count()) as pool:
        results = pool.map(process_file, file_names)
    
    files = dict(results)
    agents, query_engines = initialize_query_engines(file_names, files)
    top_agent = initialize_top_agent(agents)

    response = top_agent.query(str(query))
    print(response)
    return response

# Example usage
# import time

# start = time.time()
# filepaths = ["/UploadedFiles/PLAW-111publ148.pdf"]#"/UploadedFiles/WorkingCaseStudies.pdf", "/UploadedFiles/66085f3b7dba2-showcasing-innovative-greece.pdf"]
# query = """Can you summarize the key points of this legal Documents"""
# print(using_top_agent(filepaths, query))
# end = time.time()
# print(f"Time taken: {end - start}")

