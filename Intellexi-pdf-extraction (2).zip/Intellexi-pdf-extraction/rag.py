from flask import Blueprint, render_template,jsonify,request
from conn.mongodb import get_all_files,get_file_by_id,get_cat_by_id

from llama_index.core import (
    VectorStoreIndex,
    StorageContext,
    load_index_from_storage,
    load_indices_from_storage,
    SummaryIndex,
    ServiceContext,
    Document,
    SimpleDirectoryReader
)
from llama_index.agent.openai import OpenAIAssistantAgent
from llama_index.legacy.tools import QueryEngineTool
import os
from llama_index.multi_modal_llms.openai import OpenAIMultiModal
from llama_index.core.multi_modal_llms.generic_utils import load_image_urls
from top_agent_file import using_top_agent,vector_index_and_summary_index
from agent_composable_grapgh import using_top_agent_with_llama
import asyncio
from ensemble_agent import ensembleAgent
from vectara_agent import using_vectara_agent

rag_bp = Blueprint("Rag", __name__, template_folder="templates", static_folder="static")


@rag_bp.get("/query_agent")
def Rag_agent():
    try:
        docs = get_all_files()
        return render_template("queryagent.html", categories=docs)
    except Exception as e:
        return render_template("queryagent.html", categories=[])


def check_multile_index(index):
    new_index = index.split(",")
    multiple_indices = os.listdir("multiple_indices")
    for each in multiple_indices:
        ids = each.split("-")
        if len(ids) == len(new_index):
            if all(id in new_index for id in ids):
                print("yess", ids)
                return ids
    return None


def create_agent_indices(documents, persist_dir_path, agent_type="simple-agent"):
    service_context = ServiceContext.from_defaults(chunk_size=1024)
    if agent_type == "simple-agent":
        if not os.path.exists(os.path.join(persist_dir_path, "vector_index")):
            print(
                "    Creating Vector Index  on {}".format(
                    os.path.join(persist_dir_path, "vector_index")
                )
            )
            nodes = service_context.node_parser.get_nodes_from_documents(documents)
            vector_index = VectorStoreIndex(nodes)
            vector_index.storage_context.persist(
                persist_dir=os.path.join(persist_dir_path, "vector_index")
            )
    else:
        nodes = service_context.node_parser.get_nodes_from_documents(documents)
        storage_context = StorageContext.from_defaults()
        storage_context.docstore.add_documents(nodes)
        print("summary index   :", os.path.join(persist_dir_path, "summary_index"))
        if not os.path.exists(os.path.join(persist_dir_path, "summary_index")):
            summary_index = SummaryIndex(nodes, storage_context=storage_context)
            summary_index.storage_context.persist(
                persist_dir=os.path.join(persist_dir_path, "summary_index")
            )
        if not os.path.exists(os.path.join(persist_dir_path, "vector_index")):
            vector_index = VectorStoreIndex(nodes, storage_context=storage_context)
            vector_index.storage_context.persist(
                persist_dir=os.path.join(persist_dir_path, "vector_index")
            )

def get_correct_path(doc_ids):
    if isinstance(doc_ids, list):
        new_index = doc_ids
    else:
        new_index = doc_ids.split(",")
    print("new_index===>",new_index)
    multiple_indices = os.listdir("multiple_indices")
    print("multiple_indices====",multiple_indices)
    for each in multiple_indices:
        ids = each.split("-")
        if len(ids) == len(new_index):
            if all(id in new_index for id in ids):
                print("yess", ids)
                return each
    return None


@rag_bp.get("/ask_agent")
def Rag_query():
    print("----------------         asking agent   -------------- ")
    query = request.args.get("query")
    doc_id = request.args.get("docCategory")
    agent_type = request.args.get("agent", None)
    print("==========docid==========", doc_id)
    print("*********", doc_id, "query========", query, agent_type)
    print(type(doc_id))
    doc_ids = doc_id.split(",")
    print(doc_ids)
    if len(doc_ids)==1:
        doc=get_file_by_id(doc_id)
        category=get_cat_by_id(doc["category_id"])
        file_type=category["file_type"]
        if file_type=="image":
            image_documents=SimpleDirectoryReader(input_files=[doc["file_path"]]).load_data()
            print("---------------------------------------------------------------------")
            print("&"*30)
            print(image_documents)
            openai_mm_llm = OpenAIMultiModal(
            model="gpt-4-vision-preview", max_new_tokens=300
            )
            complete_response = openai_mm_llm.complete(
                prompt=query,
                image_documents=image_documents
            )
            print(complete_response)
            print(type(complete_response))
            print(dir(complete_response))

            return jsonify({"response": complete_response.text})
            # return jsonify({"message":"hi"})
        elif agent_type == "simple-agent":
            print("Inside agent vector inex --block")
            persist_path = os.path.join("indices", doc_id, "vector_index")
            print("=========", persist_path)
            storage_context = StorageContext.from_defaults(persist_dir=persist_path)
            print("after storage context----------", persist_path)
            print(storage_context)

            try:
                print(":-------trying--------------------")
                index = load_index_from_storage(storage_context=storage_context)
                query_engine = index.as_query_engine()
                print("-------------engine loaded---------------")
                res = query_engine.query(query)
                print("-------------response Generated---------------")
                print(res.response)
                return jsonify({"response": res.response})
            except Exception as e:
                print("----------------------Exception-------1---------------------",e)
                try:
                    index = load_indices_from_storage(storage_context=storage_context)
                    query_engine = index[0].as_query_engine()
                    print("-------------engine loaded---------------")

                    res = query_engine.query(query)
                    print("-------------response Generated---------------")

                    print(res.response)
                    return jsonify({"response": res.response})
                except Exception as e:
                    print("----------------------Exception-------2---------------------",e)

                    index = load_indices_from_storage(storage_context=storage_context)
                    print("loadied index")
                    print(index)
                    query_engine = index[0].as_query_engine()
                    res = query_engine.query(query)

                    print(res.response)
                    return jsonify({"response": res.response})
                finally:
                    return jsonify({"response":"An Unexpected error Occured"})
            finally:
                print("--------------finally----------------")
                if res:
                    return jsonify({"response": res.response})
                else:
                    return jsonify({"response":"An Unexpected error Occured"})
        elif agent_type=="top-agent":
            input_files=[]
            for doc_id in doc_ids:
                doc=get_file_by_id(doc_id)
                input_files.append(doc["file_path"])
            print("input_files======>",input_files)
            if input_files and not query:
                val1,val2=vector_index_and_summary_index(input_files)
                print("val1,val2===>",val1,val2)
                return jsonify({"response": True})
            if input_files and query:
                res=using_top_agent(input_files,query)
                print("res======>",res)
                return jsonify({"response": str(res)})
        elif agent_type == "graph-agent":
            input_files = []
            for doc_id in doc_ids:
                doc = get_file_by_id(doc_id)
                input_files.append(doc["file_path"])
            print("input_files======>", input_files)
            res = using_top_agent_with_llama(input_files, query)
            print("res======>", res)
            return jsonify({"response": str(res)})
        elif agent_type == "ensemble-agent":
            input_files = []
            for doc_id in doc_ids:
                doc = get_file_by_id(doc_id)
                input_files.append(doc["file_path"])
            print("input_files======>", input_files)
            res = asyncio.run(ensembleAgent(input_files, query))
            print("res======>", res)
            return jsonify({"response": str(res)})
        elif agent_type=="vectara-agent":
            input_files=[]
            for doc_id in doc_ids:
                doc=get_file_by_id(doc_id)
                input_files.append(doc["file_path"])
            print("input_files======>",input_files)
            res=using_vectara_agent(input_files,query)
            print("res======>",res)
            return jsonify({"response": str(res)})

        elif agent_type=="composable-agent":
            print(os.path.join("indices", doc_id, "vector_index"))
            persist_path = os.path.join("indices", doc_id, "vector_index")
            vector_storage = StorageContext.from_defaults(persist_dir=persist_path)
            print("-----------------tryng 1----------",vector_storage)
            try:
                vector_index = load_index_from_storage(storage_context=vector_storage)
            except Exception as e:
                print(e)
                vector_index = load_indices_from_storage(storage_context=vector_storage)

            vector_query_engine = vector_index.as_query_engine()
            vector_tool = QueryEngineTool.from_defaults(
                query_engine=vector_query_engine,
                name="vector_tool",
                description=(
                    "Useful for retrieving specific context to answer specific questions about the data"
                ),
            )

            summary_storage = StorageContext.from_defaults(
                persist_dir=os.path.join("indices", doc_id, "summary_index")
            )
            print("summary storage----------",summary_storage)
            print("---------trying 2----------")

            try:
                summary_index = load_index_from_storage(storage_context=summary_storage)
            except:
                summary_index = load_indices_from_storage(storage_context=summary_storage)
            summary_query_engine = summary_index.as_query_engine(
                response_mode="tree_summarize",
                use_async=True,
            )

            summary_tool = QueryEngineTool.from_defaults(
                query_engine=summary_query_engine,
                name="summary_tool",
                description=("Useful for summarization questions related to the data"),
            )

            agent = OpenAIAssistantAgent.from_new(
                name="QA bot",
                instructions="You are a bot designed to answer questions about the author",
                openai_tools=[],
                tools=[summary_tool, vector_tool],
                verbose=True,
                run_retrieve_sleep_time=1.0,
            )
            res = agent.query(query)
            print(res.response)
            return jsonify({"response": res.response})
    else:
        doc_path = get_correct_path(doc_ids)
        if (
            agent_type != "top-agent"
            and agent_type != "graph-agent"
            and agent_type != "ensemble-agent"
            and agent_type != "vectara-agent"
        ):
            multi_index_path = os.path.join("multiple_indices", doc_path)

        if agent_type == "simple-agent":
            index_path = os.path.join(multi_index_path, "vector_index")
            storage_context = StorageContext.from_defaults(persist_dir=index_path)
            try:
                index = load_index_from_storage(storage_context=storage_context)
                query_engine = index.as_query_engine()
                res = query_engine.query(query)
                print(res.response)
                return jsonify({"response": res.response})
            except :
                index = load_indices_from_storage(storage_context=storage_context)
                query_engine = index[0].as_query_engine()
                res = query_engine.query(query)
                print(res.response)
                return jsonify({"response": res.response})

        elif agent_type=="top-agent":
            input_files=[]
            for doc_id in doc_ids:
                doc=get_file_by_id(doc_id)
                input_files.append(doc["file_path"])
            print("input_files======>",input_files)
            res=using_top_agent(input_files,query)
            print("res======>",res)
            return jsonify({"response": str(res)})

        elif agent_type == "graph-agent":
            input_files = []
            for doc_id in doc_ids:
                doc = get_file_by_id(doc_id)
                input_files.append(doc["file_path"])
            print("input_files======>", input_files)
            res = using_top_agent_with_llama(input_files, query)
            print("res======>", res)
            return jsonify({"response": str(res)})
        elif agent_type=="vectara-agent":
            input_files=[]
            for doc_id in doc_ids:
                doc=get_file_by_id(doc_id)
                input_files.append(doc["file_path"])
            print("input_files======>",input_files)
            res=using_vectara_agent(input_files,query)
            print("res======>",res)
            return jsonify({"response": str(res)})
        elif agent_type == "ensemble-agent":
            input_files = []
            for doc_id in doc_ids:
                doc = get_file_by_id(doc_id)
                input_files.append(doc["file_path"])
            print("input_files======>", input_files)
            res = asyncio.run(ensembleAgent(input_files, query))
            print("res======>", res)
            return jsonify({"response": str(res)})

        else:

            vector_storage = StorageContext.from_defaults(
                persist_dir=os.path.join(multi_index_path, "vector_index")
            )
            vector_index = load_index_from_storage(storage_context=vector_storage)
            vector_query_engine = vector_index.as_query_engine()
            vector_tool = QueryEngineTool.from_defaults(
                query_engine=vector_query_engine,
                name="vector_tool",
                description=(
                    "Useful for retrieving specific context to answer specific questions about the data"
                ),
            )
            summary_storage = StorageContext.from_defaults(
                persist_dir=os.path.join(multi_index_path, "summary_index")
            )
            summary_index = load_index_from_storage(storage_context=summary_storage)
            summary_query_engine = summary_index.as_query_engine(
                response_mode="tree_summarize",
                use_async=True,
            )

            summary_tool = QueryEngineTool.from_defaults(
                query_engine=summary_query_engine,
                name="summary_tool",
                description=("Useful for summarization questions related to the data"),
            )

            agent = OpenAIAssistantAgent.from_new(
                name="QA bot",
                instructions="You are a bot designed to answer questions about the author",
                openai_tools=[],
                tools=[summary_tool, vector_tool],
                verbose=True,
                run_retrieve_sleep_time=1.0,
            )
            res = agent.query(query)
            print(res.response)
            return jsonify({"response": res.response})


@rag_bp.get("/create_agent")
def create_index():
    doc_id = request.args.get("document", None)
    agent_type = request.args.get("agent", None)
    print(doc_id,agent_type)
    multi_docs=doc_id.split(",")
    if len(multi_docs)>1:
        file_type=""
    else:
        doc=get_file_by_id(doc_id)
        category=get_cat_by_id(doc["category_id"])
        file_type=category["file_type"]
    print("*****************************************")
    if file_type=="image":
        return jsonify({"status": True})
    else:
        print("==========docid==========", doc_id, agent_type)
        doc_ids = doc_id.split(",")
        if len(doc_ids) == 1:
            print("single doc")
            if agent_type == "top-agent":
                val1,val2=vector_index_and_summary_index([doc["file_path"]])
                print("val1,val2===>",val1,val2)
                return jsonify({"response": True})
            
            single_index_path = os.path.join("indices", doc_id)
            if not os.path.exists(single_index_path):
                print("Create the index")
                file = get_file_by_id(doc_id)
                docs = []
                # data = file.get("extracted_text")
                docs=SimpleDirectoryReader(input_files=[doc["file_path"]]).load_data()
                print("documents==========", len(docs))
                print("creating indices for docs")
                create_agent_indices(
                    documents=docs,
                    persist_dir_path=single_index_path,
                    agent_type=agent_type,
                )
            else:
                print("return else                ------------")
                if agent_type == "simple-agent":
                    indices = 1
                else:
                    indices = 2
                print(os.listdir(single_index_path))
                if not len(os.listdir(single_index_path)) >= indices:
                    file = get_file_by_id(doc_id)
                    docs=SimpleDirectoryReader(input_files=[doc["file_path"]]).load_data()
                    print("documents==========", len(docs))
                    create_agent_indices(
                        documents=docs,
                        persist_dir_path=single_index_path,
                        agent_type=agent_type,
                    )
                print("--------Index already exists----")
            # if agent_type == "top-agent":
            #     val1,val2,val3=vector_index_and_summary_index([doc["file_path"]])
            #     print("val1,val2,val3===>",val1,val2,val3)
            #     return jsonify({"response": str("Agent is created you can use now")})

            return jsonify({"status": True})
        elif len(doc_ids)>1:
            print("multi docs")
            if agent_type=='top-agent':
                file_names_list=[get_file_by_id(each)["file_path"] for each in doc_ids]
                print("file_names_list====>",file_names_list)
                val1,val2=vector_index_and_summary_index(file_names_list)
                print("val1,val2===>",val1,val2)
                return jsonify({"response": True})
                        
            docs=[]
            path=check_multile_index(doc_id)
            print(path)
            if path:
                index_path="-".join(path)
                if agent_type=="simple-agent":
                    indices=1
                else:
                    indices=2
                multiple_index_path = os.path.join("multiple_indices", index_path)
                if not len(os.listdir(multiple_index_path))>=indices:
                    multiple_index_path=os.path.join("multiple_indices",index_path)
                    for each in doc_ids:
                        file = get_file_by_id(each)
                        # docs.append(Document(text=str(file["extracted_text"])))
                        # docs.append(SimpleDirectoryReader(input_files=))
                        docs.append(SimpleDirectoryReader(input_files=[file["file_path"]]).load_data())
                    if (
                        agent_type != "top-agent"
                        and agent_type != "graph-agent"
                        and agent_type != "ensemble-agent"
                        and agent_type != "vectara-agent"
                    ):
                        create_agent_indices(documents=docs,persist_dir_path=multiple_index_path,agent_type=agent_type)
                    return jsonify({"status": True})
            else:
                index_path="-".join(doc_ids)
                multiple_index_path=os.path.join("multiple_indices",index_path)
                for each in doc_ids:
                    file = get_file_by_id(each)
                    # docs.append(Document(text=str(file["extracted_text"])))
                    docs.append(SimpleDirectoryReader(input_files=[file["file_path"]]).load_data())
                if agent_type != "top-agent" and agent_type != "graph-agent" and agent_type !="ensemble-agent" and agent_type !="vectara-agent":
                    create_agent_indices(documents=docs,persist_dir_path=multiple_index_path,agent_type=agent_type)
                return jsonify({"status": True})
        return jsonify({"message": "Provide a valid doc Id"})