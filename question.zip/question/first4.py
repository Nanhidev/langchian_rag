set1 = {1, 2, 3}
set2 = {3, 4, 5}

print(set1.union(set2))