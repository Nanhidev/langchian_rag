# set
set = {1,2,None , False ,"radha"}
print(set)
print(type(set))
print()

# list 
list = [12,34,56, True,"puja"]
print(list)
print(type(list))
print()

# tuple
tupla = (23,45,67,234,"nanhi",True)
print(tuple)
print(type(tuple))
print()

#dictionary
dic = {"Name":"nanhi", "Age":20,"password":1234}
print(dic)
print(type(dic))