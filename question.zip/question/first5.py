my_tuple = (10, 20, 30, 40)
print(my_tuple[0])
print(my_tuple[-1])