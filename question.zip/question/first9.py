for i in range(11):
    print(i)
    
