number = int(input("enter the number :"))

if number >0 :
    print("number is positive!")

elif number<0:
    print("number is negative !")

else :
    print("number is zero")