dic = {"name":"Alice","age": 25}
print(dic["name"])


