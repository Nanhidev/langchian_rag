#3) (A)

list = [23,45,67,8,24]
print(list[0])

#(b)
my_list = [10, 20, 30, 40, 50]
print(my_list[-1])