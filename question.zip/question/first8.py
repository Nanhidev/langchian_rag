
def add(num1, num2):
    return num1 + num2

sum = add(32,20)
print(sum)
