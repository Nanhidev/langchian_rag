dic = {"name":"Alice","age": 25}
print(dic)
print()

dic["age"] = 30
print(dic)